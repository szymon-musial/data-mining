```python
from configparser import ConfigParser
import psycopg2

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
```


```python
def config(filename='database.ini', section='postgresql'):
    # create a parser
    parser = ConfigParser()
    # read config file
    parser.read(filename)
  
    # get section, default to postgresql
    db = {}
    if parser.has_section(section):
        params = parser.items(section)
        for param in params:
            db[param[0]] = param[1]
    else:
        raise Exception('Section {0} not found in the {1} file'.format(section, filename))
  
    return db
```


```python
def connect():
    """ Connect to the PostgreSQL database server """
    measurements, stations, predictions = None, None, None

    conn = None
    try:
        # read connection parameters
        params = config()
  
        # connect to the PostgreSQL server
        print('Connecting to the PostgreSQL database...')
        conn = psycopg2.connect(**params)
          
        # create a cursor
        cur = conn.cursor()
          
    # execute a statement
        print('PostgreSQL database version:')
        cur.execute('SELECT version()')
  
        # display the PostgreSQL database server version
        db_version = cur.fetchone()
        print(db_version)
        cur.execute("""select distinct to_char("FromDateTime", 'YYYY:MM:DD-HH24'), "StationName",
            valuespairsname, avg("Value")
            from airly."JoinAll"
            where "FromDateTime" >= '2023-03-20'
            and "AveragedValueTimeType" = 2
            group by to_char("FromDateTime", 'YYYY:MM:DD-HH24'), "StationName", valuespairsname
            order by to_char("FromDateTime", 'YYYY:MM:DD-HH24');""")
        measurements = cur.fetchall()

        cur.execute("""
                    select distinct "StationName", valuespairsname
                    from airly."JoinAll"
                    order by "StationName", valuespairsname;""")
        stations = cur.fetchall()

        cur.execute("""select distinct to_char("FromDateTime", 'YYYY:MM:DD-HH24'), "StationName",
            valuespairsname, avg("Value")
            from airly."JoinAll"
            where "FromDateTime" >= '2023-03-20'
            and "AveragedValueTimeType" = 1
            group by to_char("FromDateTime", 'YYYY:MM:DD-HH24'), "StationName", valuespairsname
            order by to_char("FromDateTime", 'YYYY:MM:DD-HH24');""")
        predictions = cur.fetchall()

    # close the communication with the PostgreSQL
        cur.close()
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    finally:
        if conn is not None:
            conn.close()
            print('Database connection closed.')
    return measurements, stations, predictions
```


```python
measurements_data, stations_data, predictions_data = connect()

print(len(measurements_data))
print(len(stations_data))
print(len(predictions_data))
```

    Connecting to the PostgreSQL database...
    PostgreSQL database version:
    ('PostgreSQL 15.2 on aarch64-unknown-linux-musl, compiled by gcc (Alpine 12.2.1_git20220924-r4) 12.2.1 20220924, 64-bit',)
    Database connection closed.
    206018
    118
    50634
    


```python
print(measurements_data[100])
print(stations_data[0])
```

    ('2023:03:20-17', ' Rynek mogilany', 'TEMPERATURE', 10.24)
    (' Miętowa, prusy', 'HUMIDITY')
    


```python
df_m = pd.DataFrame(measurements_data, columns=["Time", "Station", "Pollution", "Value"])
df_m["Time"] = df_m["Time"].apply(lambda x: pd.to_datetime(x, format="%Y:%m:%d-%H"))
df_m.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Time</th>
      <th>Station</th>
      <th>Pollution</th>
      <th>Value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2023-03-20 16:00:00</td>
      <td>Miętowa, prusy</td>
      <td>HUMIDITY</td>
      <td>71.01</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2023-03-20 16:00:00</td>
      <td>Miętowa, prusy</td>
      <td>PM1</td>
      <td>20.49</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2023-03-20 16:00:00</td>
      <td>Miętowa, prusy</td>
      <td>PM10</td>
      <td>45.50</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2023-03-20 16:00:00</td>
      <td>Miętowa, prusy</td>
      <td>PM25</td>
      <td>31.98</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2023-03-20 16:00:00</td>
      <td>Miętowa, prusy</td>
      <td>PRESSURE</td>
      <td>1014.43</td>
    </tr>
  </tbody>
</table>
</div>




```python
df_p = pd.DataFrame(predictions_data, columns=["Time", "Station", "Pollution", "Value"])
df_p["Time"] = df_p["Time"].apply(lambda x: pd.to_datetime(x, format="%Y:%m:%d-%H"))
df_p.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Time</th>
      <th>Station</th>
      <th>Pollution</th>
      <th>Value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2023-03-21 16:00:00</td>
      <td>Miętowa, prusy</td>
      <td>PM10</td>
      <td>44.13</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2023-03-21 16:00:00</td>
      <td>Miętowa, prusy</td>
      <td>PM25</td>
      <td>25.58</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2023-03-21 16:00:00</td>
      <td>Niepołomice szkolna</td>
      <td>PM10</td>
      <td>38.50</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2023-03-21 16:00:00</td>
      <td>Niepołomice szkolna</td>
      <td>PM25</td>
      <td>26.44</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2023-03-21 16:00:00</td>
      <td>Rynek mogilany</td>
      <td>PM10</td>
      <td>60.82</td>
    </tr>
  </tbody>
</table>
</div>




```python
places = df_m["Station"].value_counts()
print(places)
```

    Station
    Świętego Wawrzyńca                  19523
    Franciszka Bujaka                   18173
     liski, szkolna                     15613
     Niepołomice szkolna                15602
    Krakowska - Zabierzów               15602
     Wieliczka - Karola Kuczkiewicza    15597
     Skała, rynek                       15594
    Węgrzce                             15589
     Rynek mogilany                     15586
     Miętowa, prusy                     15434
    Emaus                               13077
    Bulwarowa                           10568
    Aleja Zygmunta Krasińskiego          8551
    Skawina                              6720
    Kaszów, no2                          4789
    Name: count, dtype: int64
    


```python
stations = df_m["Pollution"].value_counts()

print(stations)
```

    Pollution
    PM10            26798
    PM25            24877
    WIND_BEARING    22672
    WIND_SPEED      22672
    PM1             21072
    PRESSURE        21056
    HUMIDITY        17457
    TEMPERATURE     17457
    NO2             15032
    O3               9278
    CO               3822
    SO2              3821
    NO                  4
    Name: count, dtype: int64
    


```python
min_time = df_m["Time"].min()
print(min_time)

max_time = df_m["Time"].max()
print(max_time)
```

    2023-03-20 16:00:00
    2023-06-10 08:00:00
    


```python
np.count_nonzero(df_m.isna().values)
```




    0




```python
df_s = pd.DataFrame(stations_data, columns=["Station", "Pollution"])
df_s.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Station</th>
      <th>Pollution</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Miętowa, prusy</td>
      <td>HUMIDITY</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Miętowa, prusy</td>
      <td>PM1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Miętowa, prusy</td>
      <td>PM10</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Miętowa, prusy</td>
      <td>PM25</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Miętowa, prusy</td>
      <td>PRESSURE</td>
    </tr>
  </tbody>
</table>
</div>




```python
def create_dataset(df_m, df_s):
    df_m["Timestamp"] = df_m["Time"].apply(lambda x: int(x.timestamp()//3600))
    N = df_s.shape[0]
    print(N)
    min_time = df_m["Timestamp"].min()
    max_time = df_m["Timestamp"].max()
    print(min_time, max_time)
    print((max_time - min_time))
    hours = int((max_time - min_time))
    data = np.full((hours, N), np.nan)
    time = min_time
    i = 0
    while time < max_time:
        hours_data = df_m.loc[df_m["Timestamp"] == time]
        for index in range(N):
            element = hours_data.loc[
                                    (hours_data["Station"] == df_s["Station"].iloc[index]) & 
                                    (hours_data["Pollution"] == df_s["Pollution"].iloc[index])]
            if len(element) > 0:
                data[i, index] = element["Value"].values[0]
        time += 1
        i += 1
    
    return data
```


```python
data = create_dataset(df_m, df_s)
print(data.shape)
```

    118
    466480 468440
    1960
    (1960, 118)
    


```python
predictions_data = create_dataset(df_p, df_s)
print(predictions_data.shape)
```

    118
    466504 468464
    1960
    (1960, 118)
    


```python
N = df_s.shape[0]
print(N)
```

    118
    


```python
df_s
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Station</th>
      <th>Pollution</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Miętowa, prusy</td>
      <td>HUMIDITY</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Miętowa, prusy</td>
      <td>PM1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Miętowa, prusy</td>
      <td>PM10</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Miętowa, prusy</td>
      <td>PM25</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Miętowa, prusy</td>
      <td>PRESSURE</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>113</th>
      <td>Świętego Wawrzyńca</td>
      <td>PM25</td>
    </tr>
    <tr>
      <th>114</th>
      <td>Świętego Wawrzyńca</td>
      <td>PRESSURE</td>
    </tr>
    <tr>
      <th>115</th>
      <td>Świętego Wawrzyńca</td>
      <td>TEMPERATURE</td>
    </tr>
    <tr>
      <th>116</th>
      <td>Świętego Wawrzyńca</td>
      <td>WIND_BEARING</td>
    </tr>
    <tr>
      <th>117</th>
      <td>Świętego Wawrzyńca</td>
      <td>WIND_SPEED</td>
    </tr>
  </tbody>
</table>
<p>118 rows × 2 columns</p>
</div>




```python
print(data.shape)
zeros = np.count_nonzero(np.isnan(data), axis=0)
print("Total empty data: ", np.count_nonzero(np.isnan(data)))
for i, n in enumerate(zeros):
    print(df_s.loc[i]["Station"], df_s.loc[i]["Pollution"], " -- ", n)
```

    (1960, 118)
    Total empty data:  25288
     Miętowa, prusy HUMIDITY  --  24
     Miętowa, prusy PM1  --  22
     Miętowa, prusy PM10  --  22
     Miętowa, prusy PM25  --  22
     Miętowa, prusy PRESSURE  --  24
     Miętowa, prusy TEMPERATURE  --  24
     Miętowa, prusy WIND_BEARING  --  54
     Miętowa, prusy WIND_SPEED  --  54
     Niepołomice szkolna HUMIDITY  --  4
     Niepołomice szkolna PM1  --  2
     Niepołomice szkolna PM10  --  2
     Niepołomice szkolna PM25  --  2
     Niepołomice szkolna PRESSURE  --  4
     Niepołomice szkolna TEMPERATURE  --  4
     Niepołomice szkolna WIND_BEARING  --  34
     Niepołomice szkolna WIND_SPEED  --  34
     Rynek mogilany HUMIDITY  --  5
     Rynek mogilany PM1  --  3
     Rynek mogilany PM10  --  3
     Rynek mogilany PM25  --  3
     Rynek mogilany PRESSURE  --  5
     Rynek mogilany TEMPERATURE  --  5
     Rynek mogilany WIND_BEARING  --  35
     Rynek mogilany WIND_SPEED  --  35
     Skała, rynek HUMIDITY  --  4
     Skała, rynek PM1  --  2
     Skała, rynek PM10  --  2
     Skała, rynek PM25  --  2
     Skała, rynek PRESSURE  --  4
     Skała, rynek TEMPERATURE  --  4
     Skała, rynek WIND_BEARING  --  34
     Skała, rynek WIND_SPEED  --  34
     Wieliczka - Karola Kuczkiewicza HUMIDITY  --  3
     Wieliczka - Karola Kuczkiewicza PM1  --  2
     Wieliczka - Karola Kuczkiewicza PM10  --  2
     Wieliczka - Karola Kuczkiewicza PM25  --  2
     Wieliczka - Karola Kuczkiewicza PRESSURE  --  3
     Wieliczka - Karola Kuczkiewicza TEMPERATURE  --  3
     Wieliczka - Karola Kuczkiewicza WIND_BEARING  --  34
     Wieliczka - Karola Kuczkiewicza WIND_SPEED  --  34
     liski, szkolna HUMIDITY  --  2
     liski, szkolna PM1  --  1
     liski, szkolna PM10  --  1
     liski, szkolna PM25  --  1
     liski, szkolna PRESSURE  --  2
     liski, szkolna TEMPERATURE  --  2
     liski, szkolna WIND_BEARING  --  33
     liski, szkolna WIND_SPEED  --  33
    Aleja Zygmunta Krasińskiego CO  --  51
    Aleja Zygmunta Krasińskiego NO  --  1959
    Aleja Zygmunta Krasińskiego NO2  --  51
    Aleja Zygmunta Krasińskiego PM10  --  82
    Aleja Zygmunta Krasińskiego PM25  --  82
    Aleja Zygmunta Krasińskiego WIND_BEARING  --  1472
    Aleja Zygmunta Krasińskiego WIND_SPEED  --  1472
    Bulwarowa CO  --  47
    Bulwarowa NO  --  1959
    Bulwarowa NO2  --  48
    Bulwarowa PM10  --  33
    Bulwarowa PM25  --  33
    Bulwarowa SO2  --  48
    Bulwarowa WIND_BEARING  --  1472
    Bulwarowa WIND_SPEED  --  1472
    Emaus NO2  --  318
    Emaus O3  --  318
    Emaus PM1  --  317
    Emaus PM10  --  317
    Emaus PM25  --  317
    Emaus PRESSURE  --  318
    Emaus WIND_BEARING  --  349
    Emaus WIND_SPEED  --  349
    Franciszka Bujaka HUMIDITY  --  137
    Franciszka Bujaka NO2  --  136
    Franciszka Bujaka O3  --  136
    Franciszka Bujaka PM1  --  136
    Franciszka Bujaka PM10  --  136
    Franciszka Bujaka PM25  --  136
    Franciszka Bujaka PRESSURE  --  137
    Franciszka Bujaka TEMPERATURE  --  137
    Franciszka Bujaka WIND_BEARING  --  168
    Franciszka Bujaka WIND_SPEED  --  168
    Kaszów, no2 NO  --  1959
    Kaszów, no2 NO2  --  44
    Kaszów, no2 O3  --  64
    Kaszów, no2 WIND_BEARING  --  1472
    Kaszów, no2 WIND_SPEED  --  1472
    Krakowska - Zabierzów NO2  --  3
    Krakowska - Zabierzów O3  --  3
    Krakowska - Zabierzów PM1  --  1
    Krakowska - Zabierzów PM10  --  1
    Krakowska - Zabierzów PM25  --  1
    Krakowska - Zabierzów PRESSURE  --  3
    Krakowska - Zabierzów WIND_BEARING  --  33
    Krakowska - Zabierzów WIND_SPEED  --  33
    Skawina NO  --  1959
    Skawina NO2  --  47
    Skawina PM10  --  39
    Skawina SO2  --  51
    Skawina WIND_BEARING  --  1472
    Skawina WIND_SPEED  --  1472
    Węgrzce HUMIDITY  --  4
    Węgrzce PM1  --  3
    Węgrzce PM10  --  3
    Węgrzce PM25  --  3
    Węgrzce PRESSURE  --  4
    Węgrzce TEMPERATURE  --  4
    Węgrzce WIND_BEARING  --  35
    Węgrzce WIND_SPEED  --  35
    Świętego Wawrzyńca HUMIDITY  --  3
    Świętego Wawrzyńca NO2  --  2
    Świętego Wawrzyńca O3  --  2
    Świętego Wawrzyńca PM1  --  2
    Świętego Wawrzyńca PM10  --  2
    Świętego Wawrzyńca PM25  --  2
    Świętego Wawrzyńca PRESSURE  --  3
    Świętego Wawrzyńca TEMPERATURE  --  3
    Świętego Wawrzyńca WIND_BEARING  --  34
    Świętego Wawrzyńca WIND_SPEED  --  34
    


```python
for i in range(1, data.shape[0]-1):
    for j in range(data.shape[1]):
        if np.isnan(data[i, j]):
            if not np.isnan(data[i-1, j]) and not np.isnan(data[i+1, j]):
                data[i, j] = (data[i-1, j] + data[i+1, j])/2

print(data.shape)
zeros = np.count_nonzero(np.isnan(data), axis=0)
print("Total empty data: ", np.count_nonzero(np.isnan(data)))
for i, n in enumerate(zeros):
    print(df_s.loc[i]["Station"], df_s.loc[i]["Pollution"], " -- ", n, " -- ", np.nanmean(data[:, i]))
```

    (1960, 118)
    Total empty data:  24944
     Miętowa, prusy HUMIDITY  --  22  --  69.68532507739938
     Miętowa, prusy PM1  --  20  --  9.454126288659795
     Miętowa, prusy PM10  --  20  --  19.66540979381443
     Miętowa, prusy PM25  --  20  --  14.551744845360822
     Miętowa, prusy PRESSURE  --  22  --  1015.0471207430339
     Miętowa, prusy TEMPERATURE  --  22  --  10.669220846233229
     Miętowa, prusy WIND_BEARING  --  52  --  160.86836215932914
     Miętowa, prusy WIND_SPEED  --  52  --  11.023402777777777
     Niepołomice szkolna HUMIDITY  --  2  --  58.87200459652707
     Niepołomice szkolna PM1  --  0  --  8.74652806122449
     Niepołomice szkolna PM10  --  0  --  18.079535714285715
     Niepołomice szkolna PM25  --  0  --  12.988915816326532
     Niepołomice szkolna PRESSURE  --  2  --  1017.2108401430031
     Niepołomice szkolna TEMPERATURE  --  2  --  10.703151174668028
     Niepołomice szkolna WIND_BEARING  --  32  --  161.5842518153527
     Niepołomice szkolna WIND_SPEED  --  32  --  10.28117479253112
     Rynek mogilany HUMIDITY  --  2  --  76.31917517875384
     Rynek mogilany PM1  --  0  --  9.09273724489796
     Rynek mogilany PM10  --  0  --  19.171627551020407
     Rynek mogilany PM25  --  0  --  14.183415816326532
     Rynek mogilany PRESSURE  --  2  --  1016.5590602655772
     Rynek mogilany TEMPERATURE  --  2  --  9.6217671092952
     Rynek mogilany WIND_BEARING  --  32  --  159.40885503112034
     Rynek mogilany WIND_SPEED  --  32  --  9.991824429460582
     Skała, rynek HUMIDITY  --  2  --  66.76822522982636
     Skała, rynek PM1  --  0  --  11.877772959183673
     Skała, rynek PM10  --  0  --  24.56342857142857
     Skała, rynek PM25  --  0  --  18.36188520408163
     Skała, rynek PRESSURE  --  2  --  1017.6083503575076
     Skała, rynek TEMPERATURE  --  2  --  10.190505617977529
     Skała, rynek WIND_BEARING  --  32  --  158.97205134854772
     Skała, rynek WIND_SPEED  --  32  --  11.724039159751037
     Wieliczka - Karola Kuczkiewicza HUMIDITY  --  0  --  74.52325510204082
     Wieliczka - Karola Kuczkiewicza PM1  --  0  --  10.142369897959183
     Wieliczka - Karola Kuczkiewicza PM10  --  0  --  19.444545918367346
     Wieliczka - Karola Kuczkiewicza PM25  --  0  --  14.609864795918368
     Wieliczka - Karola Kuczkiewicza PRESSURE  --  0  --  1016.2512448979592
     Wieliczka - Karola Kuczkiewicza TEMPERATURE  --  0  --  10.872734693877552
     Wieliczka - Karola Kuczkiewicza WIND_BEARING  --  32  --  160.29446447095435
     Wieliczka - Karola Kuczkiewicza WIND_SPEED  --  32  --  10.383676089211619
     liski, szkolna HUMIDITY  --  0  --  68.97818112244899
     liski, szkolna PM1  --  0  --  10.670844387755103
     liski, szkolna PM10  --  0  --  22.475915816326534
     liski, szkolna PM25  --  0  --  16.892780612244902
     liski, szkolna PRESSURE  --  0  --  1009.8604591836735
     liski, szkolna TEMPERATURE  --  0  --  12.394051020408163
     liski, szkolna WIND_BEARING  --  32  --  156.8525544605809
     liski, szkolna WIND_SPEED  --  32  --  10.448214470954358
    Aleja Zygmunta Krasińskiego CO  --  34  --  570.7193535825546
    Aleja Zygmunta Krasińskiego NO  --  1959  --  39.97
    Aleja Zygmunta Krasińskiego NO2  --  34  --  46.782725856697816
    Aleja Zygmunta Krasińskiego PM10  --  81  --  30.620848855774348
    Aleja Zygmunta Krasińskiego PM25  --  81  --  17.35980042575838
    Aleja Zygmunta Krasińskiego WIND_BEARING  --  1472  --  221.08196721311475
    Aleja Zygmunta Krasińskiego WIND_SPEED  --  1472  --  12.676434426229507
    Bulwarowa CO  --  34  --  360.5791536863967
    Bulwarowa NO  --  1959  --  2.81
    Bulwarowa NO2  --  35  --  18.443064935064935
    Bulwarowa PM10  --  32  --  23.533820020746887
    Bulwarowa PM25  --  32  --  14.030832468879668
    Bulwarowa SO2  --  34  --  4.167292315680166
    Bulwarowa WIND_BEARING  --  1472  --  221.08196721311475
    Bulwarowa WIND_SPEED  --  1472  --  12.676434426229507
    Emaus NO2  --  313  --  36.0604189435337
    Emaus O3  --  313  --  43.90836369156042
    Emaus PM1  --  313  --  8.977473183566081
    Emaus PM10  --  313  --  18.90398907103825
    Emaus PM25  --  313  --  12.8540457397288
    Emaus PRESSURE  --  313  --  1016.6291297308238
    Emaus WIND_BEARING  --  345  --  159.06767337461298
    Emaus WIND_SPEED  --  345  --  11.192568111455106
    Franciszka Bujaka HUMIDITY  --  135  --  77.39225753424657
    Franciszka Bujaka NO2  --  135  --  33.23637808219178
    Franciszka Bujaka O3  --  135  --  44.51516712328767
    Franciszka Bujaka PM1  --  135  --  12.79030410958904
    Franciszka Bujaka PM10  --  135  --  27.090027397260275
    Franciszka Bujaka PM25  --  135  --  19.57548219178082
    Franciszka Bujaka PRESSURE  --  135  --  1014.5408739726028
    Franciszka Bujaka TEMPERATURE  --  135  --  12.227753424657534
    Franciszka Bujaka WIND_BEARING  --  167  --  158.76990658114892
    Franciszka Bujaka WIND_SPEED  --  167  --  10.712306190741774
    Kaszów, no2 NO  --  1959  --  2.85
    Kaszów, no2 NO2  --  32  --  9.923386929460582
    Kaszów, no2 O3  --  52  --  65.27929507337527
    Kaszów, no2 WIND_BEARING  --  1472  --  221.08196721311475
    Kaszów, no2 WIND_SPEED  --  1472  --  12.676434426229507
    Krakowska - Zabierzów NO2  --  2  --  30.307901770514132
    Krakowska - Zabierzów O3  --  2  --  48.676415560095336
    Krakowska - Zabierzów PM1  --  0  --  12.688586734693876
    Krakowska - Zabierzów PM10  --  0  --  25.7189175170068
    Krakowska - Zabierzów PM25  --  0  --  19.43680357142857
    Krakowska - Zabierzów PRESSURE  --  2  --  1016.6162248893429
    Krakowska - Zabierzów WIND_BEARING  --  32  --  158.28216934647304
    Krakowska - Zabierzów WIND_SPEED  --  32  --  11.260119294605808
    Skawina NO  --  1959  --  3.51
    Skawina NO2  --  34  --  14.768138110072691
    Skawina PM10  --  37  --  18.94821112844514
    Skawina SO2  --  32  --  4.507767634854771
    Skawina WIND_BEARING  --  1472  --  221.08196721311475
    Skawina WIND_SPEED  --  1472  --  12.676434426229507
    Węgrzce HUMIDITY  --  0  --  69.56992857142858
    Węgrzce PM1  --  0  --  10.385563775510203
    Węgrzce PM10  --  0  --  21.289948979591838
    Węgrzce PM25  --  0  --  15.32813775510204
    Węgrzce PRESSURE  --  0  --  1016.8748163265307
    Węgrzce TEMPERATURE  --  0  --  10.426793367346939
    Węgrzce WIND_BEARING  --  32  --  159.70078708506225
    Węgrzce WIND_SPEED  --  32  --  10.88548755186722
    Świętego Wawrzyńca HUMIDITY  --  0  --  76.01311989795919
    Świętego Wawrzyńca NO2  --  0  --  29.128650510204082
    Świętego Wawrzyńca O3  --  0  --  53.731372448979585
    Świętego Wawrzyńca PM1  --  0  --  8.812510204081633
    Świętego Wawrzyńca PM10  --  0  --  20.245854591836736
    Świętego Wawrzyńca PM25  --  0  --  14.800895408163266
    Świętego Wawrzyńca PRESSURE  --  0  --  1017.5703188775511
    Świętego Wawrzyńca TEMPERATURE  --  0  --  12.350665816326531
    Świętego Wawrzyńca WIND_BEARING  --  32  --  157.78342193983403
    Świętego Wawrzyńca WIND_SPEED  --  32  --  10.545630186721992
    


```python
print(predictions_data.shape)
zeros = np.count_nonzero(np.isnan(predictions_data), axis=0)
print("Zeros: ", zeros)
print("Total empty data: ", np.count_nonzero(np.isnan(predictions_data)))
for i, n in enumerate(zeros):
    print(df_s.loc[i]["Station"], df_s.loc[i]["Pollution"], " -- ", n)

predictions_data[np.isnan(predictions_data)] = 0
```

    (1960, 118)
    Zeros:  [1960 1960   58   58 1960 1960 1960 1960 1960 1960   55   55 1960 1960
     1960 1960 1960 1960   37   37 1960 1960 1960 1960 1960 1960   46   46
     1960 1960 1960 1960 1960 1960   46   46 1960 1960 1960 1960 1960 1960
       44   44 1960 1960 1960 1960 1960 1960 1960  109  109 1960 1960 1960
     1960 1960   58   58 1960 1960 1960 1960 1960 1960  349  349 1960 1960
     1960 1960 1960 1960 1960  184  184 1960 1960 1960 1960 1960 1960 1960
     1960 1960 1960 1960 1960   50   50 1960 1960 1960 1960 1960   61 1960
     1960 1960 1960 1960   38   38 1960 1960 1960 1960 1960 1960 1960 1960
       52   52 1960 1960 1960 1960]
    Total empty data:  180673
     Miętowa, prusy HUMIDITY  --  1960
     Miętowa, prusy PM1  --  1960
     Miętowa, prusy PM10  --  58
     Miętowa, prusy PM25  --  58
     Miętowa, prusy PRESSURE  --  1960
     Miętowa, prusy TEMPERATURE  --  1960
     Miętowa, prusy WIND_BEARING  --  1960
     Miętowa, prusy WIND_SPEED  --  1960
     Niepołomice szkolna HUMIDITY  --  1960
     Niepołomice szkolna PM1  --  1960
     Niepołomice szkolna PM10  --  55
     Niepołomice szkolna PM25  --  55
     Niepołomice szkolna PRESSURE  --  1960
     Niepołomice szkolna TEMPERATURE  --  1960
     Niepołomice szkolna WIND_BEARING  --  1960
     Niepołomice szkolna WIND_SPEED  --  1960
     Rynek mogilany HUMIDITY  --  1960
     Rynek mogilany PM1  --  1960
     Rynek mogilany PM10  --  37
     Rynek mogilany PM25  --  37
     Rynek mogilany PRESSURE  --  1960
     Rynek mogilany TEMPERATURE  --  1960
     Rynek mogilany WIND_BEARING  --  1960
     Rynek mogilany WIND_SPEED  --  1960
     Skała, rynek HUMIDITY  --  1960
     Skała, rynek PM1  --  1960
     Skała, rynek PM10  --  46
     Skała, rynek PM25  --  46
     Skała, rynek PRESSURE  --  1960
     Skała, rynek TEMPERATURE  --  1960
     Skała, rynek WIND_BEARING  --  1960
     Skała, rynek WIND_SPEED  --  1960
     Wieliczka - Karola Kuczkiewicza HUMIDITY  --  1960
     Wieliczka - Karola Kuczkiewicza PM1  --  1960
     Wieliczka - Karola Kuczkiewicza PM10  --  46
     Wieliczka - Karola Kuczkiewicza PM25  --  46
     Wieliczka - Karola Kuczkiewicza PRESSURE  --  1960
     Wieliczka - Karola Kuczkiewicza TEMPERATURE  --  1960
     Wieliczka - Karola Kuczkiewicza WIND_BEARING  --  1960
     Wieliczka - Karola Kuczkiewicza WIND_SPEED  --  1960
     liski, szkolna HUMIDITY  --  1960
     liski, szkolna PM1  --  1960
     liski, szkolna PM10  --  44
     liski, szkolna PM25  --  44
     liski, szkolna PRESSURE  --  1960
     liski, szkolna TEMPERATURE  --  1960
     liski, szkolna WIND_BEARING  --  1960
     liski, szkolna WIND_SPEED  --  1960
    Aleja Zygmunta Krasińskiego CO  --  1960
    Aleja Zygmunta Krasińskiego NO  --  1960
    Aleja Zygmunta Krasińskiego NO2  --  1960
    Aleja Zygmunta Krasińskiego PM10  --  109
    Aleja Zygmunta Krasińskiego PM25  --  109
    Aleja Zygmunta Krasińskiego WIND_BEARING  --  1960
    Aleja Zygmunta Krasińskiego WIND_SPEED  --  1960
    Bulwarowa CO  --  1960
    Bulwarowa NO  --  1960
    Bulwarowa NO2  --  1960
    Bulwarowa PM10  --  58
    Bulwarowa PM25  --  58
    Bulwarowa SO2  --  1960
    Bulwarowa WIND_BEARING  --  1960
    Bulwarowa WIND_SPEED  --  1960
    Emaus NO2  --  1960
    Emaus O3  --  1960
    Emaus PM1  --  1960
    Emaus PM10  --  349
    Emaus PM25  --  349
    Emaus PRESSURE  --  1960
    Emaus WIND_BEARING  --  1960
    Emaus WIND_SPEED  --  1960
    Franciszka Bujaka HUMIDITY  --  1960
    Franciszka Bujaka NO2  --  1960
    Franciszka Bujaka O3  --  1960
    Franciszka Bujaka PM1  --  1960
    Franciszka Bujaka PM10  --  184
    Franciszka Bujaka PM25  --  184
    Franciszka Bujaka PRESSURE  --  1960
    Franciszka Bujaka TEMPERATURE  --  1960
    Franciszka Bujaka WIND_BEARING  --  1960
    Franciszka Bujaka WIND_SPEED  --  1960
    Kaszów, no2 NO  --  1960
    Kaszów, no2 NO2  --  1960
    Kaszów, no2 O3  --  1960
    Kaszów, no2 WIND_BEARING  --  1960
    Kaszów, no2 WIND_SPEED  --  1960
    Krakowska - Zabierzów NO2  --  1960
    Krakowska - Zabierzów O3  --  1960
    Krakowska - Zabierzów PM1  --  1960
    Krakowska - Zabierzów PM10  --  50
    Krakowska - Zabierzów PM25  --  50
    Krakowska - Zabierzów PRESSURE  --  1960
    Krakowska - Zabierzów WIND_BEARING  --  1960
    Krakowska - Zabierzów WIND_SPEED  --  1960
    Skawina NO  --  1960
    Skawina NO2  --  1960
    Skawina PM10  --  61
    Skawina SO2  --  1960
    Skawina WIND_BEARING  --  1960
    Skawina WIND_SPEED  --  1960
    Węgrzce HUMIDITY  --  1960
    Węgrzce PM1  --  1960
    Węgrzce PM10  --  38
    Węgrzce PM25  --  38
    Węgrzce PRESSURE  --  1960
    Węgrzce TEMPERATURE  --  1960
    Węgrzce WIND_BEARING  --  1960
    Węgrzce WIND_SPEED  --  1960
    Świętego Wawrzyńca HUMIDITY  --  1960
    Świętego Wawrzyńca NO2  --  1960
    Świętego Wawrzyńca O3  --  1960
    Świętego Wawrzyńca PM1  --  1960
    Świętego Wawrzyńca PM10  --  52
    Świętego Wawrzyńca PM25  --  52
    Świętego Wawrzyńca PRESSURE  --  1960
    Świętego Wawrzyńca TEMPERATURE  --  1960
    Świętego Wawrzyńca WIND_BEARING  --  1960
    Świętego Wawrzyńca WIND_SPEED  --  1960
    


```python
print(np.nanmean(data, axis=0).shape)
```

    (118,)
    


```python
for i in range(data.shape[1]):
    mask = np.isnan(data[:, i])
    data[mask, i] = np.nanmean(data[:, i])
np.count_nonzero(np.isnan(data))
```




    0




```python
print(data.shape)
zeros = np.count_nonzero(np.isnan(data), axis=0)
print("Total empty data: ", np.count_nonzero(np.isnan(data)))
for i, n in enumerate(zeros):
    print(df_s.loc[i]["Station"], df_s.loc[i]["Pollution"], " -- ", n, " -- ", np.nanmean(data[:, i]))
```

    (1960, 118)
    Total empty data:  0
     Miętowa, prusy HUMIDITY  --  0  --  69.68532507739938
     Miętowa, prusy PM1  --  0  --  9.454126288659793
     Miętowa, prusy PM10  --  0  --  19.665409793814433
     Miętowa, prusy PM25  --  0  --  14.551744845360824
     Miętowa, prusy PRESSURE  --  0  --  1015.047120743034
     Miętowa, prusy TEMPERATURE  --  0  --  10.66922084623323
     Miętowa, prusy WIND_BEARING  --  0  --  160.86836215932914
     Miętowa, prusy WIND_SPEED  --  0  --  11.023402777777777
     Niepołomice szkolna HUMIDITY  --  0  --  58.87200459652707
     Niepołomice szkolna PM1  --  0  --  8.74652806122449
     Niepołomice szkolna PM10  --  0  --  18.079535714285715
     Niepołomice szkolna PM25  --  0  --  12.988915816326532
     Niepołomice szkolna PRESSURE  --  0  --  1017.2108401430031
     Niepołomice szkolna TEMPERATURE  --  0  --  10.703151174668028
     Niepołomice szkolna WIND_BEARING  --  0  --  161.58425181535267
     Niepołomice szkolna WIND_SPEED  --  0  --  10.281174792531118
     Rynek mogilany HUMIDITY  --  0  --  76.31917517875385
     Rynek mogilany PM1  --  0  --  9.09273724489796
     Rynek mogilany PM10  --  0  --  19.171627551020407
     Rynek mogilany PM25  --  0  --  14.183415816326532
     Rynek mogilany PRESSURE  --  0  --  1016.5590602655772
     Rynek mogilany TEMPERATURE  --  0  --  9.621767109295199
     Rynek mogilany WIND_BEARING  --  0  --  159.40885503112034
     Rynek mogilany WIND_SPEED  --  0  --  9.991824429460578
     Skała, rynek HUMIDITY  --  0  --  66.76822522982636
     Skała, rynek PM1  --  0  --  11.877772959183673
     Skała, rynek PM10  --  0  --  24.56342857142857
     Skała, rynek PM25  --  0  --  18.36188520408163
     Skała, rynek PRESSURE  --  0  --  1017.6083503575076
     Skała, rynek TEMPERATURE  --  0  --  10.190505617977529
     Skała, rynek WIND_BEARING  --  0  --  158.97205134854772
     Skała, rynek WIND_SPEED  --  0  --  11.724039159751035
     Wieliczka - Karola Kuczkiewicza HUMIDITY  --  0  --  74.52325510204082
     Wieliczka - Karola Kuczkiewicza PM1  --  0  --  10.142369897959183
     Wieliczka - Karola Kuczkiewicza PM10  --  0  --  19.444545918367346
     Wieliczka - Karola Kuczkiewicza PM25  --  0  --  14.609864795918368
     Wieliczka - Karola Kuczkiewicza PRESSURE  --  0  --  1016.2512448979592
     Wieliczka - Karola Kuczkiewicza TEMPERATURE  --  0  --  10.872734693877552
     Wieliczka - Karola Kuczkiewicza WIND_BEARING  --  0  --  160.29446447095435
     Wieliczka - Karola Kuczkiewicza WIND_SPEED  --  0  --  10.383676089211619
     liski, szkolna HUMIDITY  --  0  --  68.97818112244899
     liski, szkolna PM1  --  0  --  10.670844387755103
     liski, szkolna PM10  --  0  --  22.475915816326534
     liski, szkolna PM25  --  0  --  16.892780612244902
     liski, szkolna PRESSURE  --  0  --  1009.8604591836735
     liski, szkolna TEMPERATURE  --  0  --  12.394051020408163
     liski, szkolna WIND_BEARING  --  0  --  156.85255446058088
     liski, szkolna WIND_SPEED  --  0  --  10.448214470954357
    Aleja Zygmunta Krasińskiego CO  --  0  --  570.7193535825545
    Aleja Zygmunta Krasińskiego NO  --  0  --  39.97000000000001
    Aleja Zygmunta Krasińskiego NO2  --  0  --  46.782725856697816
    Aleja Zygmunta Krasińskiego PM10  --  0  --  30.620848855774348
    Aleja Zygmunta Krasińskiego PM25  --  0  --  17.359800425758383
    Aleja Zygmunta Krasińskiego WIND_BEARING  --  0  --  221.08196721311472
    Aleja Zygmunta Krasińskiego WIND_SPEED  --  0  --  12.676434426229509
    Bulwarowa CO  --  0  --  360.5791536863967
    Bulwarowa NO  --  0  --  2.81
    Bulwarowa NO2  --  0  --  18.443064935064935
    Bulwarowa PM10  --  0  --  23.533820020746884
    Bulwarowa PM25  --  0  --  14.030832468879668
    Bulwarowa SO2  --  0  --  4.167292315680166
    Bulwarowa WIND_BEARING  --  0  --  221.08196721311472
    Bulwarowa WIND_SPEED  --  0  --  12.676434426229509
    Emaus NO2  --  0  --  36.0604189435337
    Emaus O3  --  0  --  43.90836369156042
    Emaus PM1  --  0  --  8.97747318356608
    Emaus PM10  --  0  --  18.90398907103825
    Emaus PM25  --  0  --  12.8540457397288
    Emaus PRESSURE  --  0  --  1016.6291297308237
    Emaus WIND_BEARING  --  0  --  159.06767337461298
    Emaus WIND_SPEED  --  0  --  11.192568111455108
    Franciszka Bujaka HUMIDITY  --  0  --  77.39225753424657
    Franciszka Bujaka NO2  --  0  --  33.236378082191784
    Franciszka Bujaka O3  --  0  --  44.515167123287675
    Franciszka Bujaka PM1  --  0  --  12.790304109589043
    Franciszka Bujaka PM10  --  0  --  27.090027397260275
    Franciszka Bujaka PM25  --  0  --  19.575482191780818
    Franciszka Bujaka PRESSURE  --  0  --  1014.5408739726029
    Franciszka Bujaka TEMPERATURE  --  0  --  12.227753424657534
    Franciszka Bujaka WIND_BEARING  --  0  --  158.7699065811489
    Franciszka Bujaka WIND_SPEED  --  0  --  10.712306190741772
    Kaszów, no2 NO  --  0  --  2.850000000000001
    Kaszów, no2 NO2  --  0  --  9.92338692946058
    Kaszów, no2 O3  --  0  --  65.27929507337527
    Kaszów, no2 WIND_BEARING  --  0  --  221.08196721311472
    Kaszów, no2 WIND_SPEED  --  0  --  12.676434426229509
    Krakowska - Zabierzów NO2  --  0  --  30.307901770514132
    Krakowska - Zabierzów O3  --  0  --  48.676415560095336
    Krakowska - Zabierzów PM1  --  0  --  12.688586734693876
    Krakowska - Zabierzów PM10  --  0  --  25.7189175170068
    Krakowska - Zabierzów PM25  --  0  --  19.43680357142857
    Krakowska - Zabierzów PRESSURE  --  0  --  1016.6162248893429
    Krakowska - Zabierzów WIND_BEARING  --  0  --  158.282169346473
    Krakowska - Zabierzów WIND_SPEED  --  0  --  11.26011929460581
    Skawina NO  --  0  --  3.5099999999999985
    Skawina NO2  --  0  --  14.768138110072691
    Skawina PM10  --  0  --  18.948211128445138
    Skawina SO2  --  0  --  4.507767634854772
    Skawina WIND_BEARING  --  0  --  221.08196721311472
    Skawina WIND_SPEED  --  0  --  12.676434426229509
    Węgrzce HUMIDITY  --  0  --  69.56992857142858
    Węgrzce PM1  --  0  --  10.385563775510203
    Węgrzce PM10  --  0  --  21.289948979591838
    Węgrzce PM25  --  0  --  15.32813775510204
    Węgrzce PRESSURE  --  0  --  1016.8748163265307
    Węgrzce TEMPERATURE  --  0  --  10.426793367346939
    Węgrzce WIND_BEARING  --  0  --  159.70078708506222
    Węgrzce WIND_SPEED  --  0  --  10.88548755186722
    Świętego Wawrzyńca HUMIDITY  --  0  --  76.01311989795919
    Świętego Wawrzyńca NO2  --  0  --  29.128650510204082
    Świętego Wawrzyńca O3  --  0  --  53.731372448979585
    Świętego Wawrzyńca PM1  --  0  --  8.812510204081633
    Świętego Wawrzyńca PM10  --  0  --  20.245854591836736
    Świętego Wawrzyńca PM25  --  0  --  14.800895408163266
    Świętego Wawrzyńca PRESSURE  --  0  --  1017.5703188775511
    Świętego Wawrzyńca TEMPERATURE  --  0  --  12.350665816326531
    Świętego Wawrzyńca WIND_BEARING  --  0  --  157.78342193983406
    Świętego Wawrzyńca WIND_SPEED  --  0  --  10.545630186721992
    


```python
import minkf as kf

x0 = data[0]

print(data[0].shape)
Cest0 = np.diag(np.diag(np.ones((N, N))))
M = np.diag(np.diag(np.ones((N, N))))
K = np.diag(np.diag(np.ones((N, N))))
Q = 0.1*np.diag(np.diag(np.ones((N, N))))

error = 1
R = error*np.diag(np.diag(np.ones((N, N))))

res = kf.run_filter(data, x0, Cest0, M, K, Q, R, likelihood=True)
```

    (118,)
    


```python
print(np.array(res["x"]).shape)
print(data.shape)
```

    (1960, 118)
    (1960, 118)
    


```python
print(data[6, :10])
print(np.array(res["x"])[6, :10])
```

    [  88.25         43.89         90.58         72.97       1014.67
        7.43        160.86836216   11.02340278   87.2          28.8       ]
    [  83.67270651   33.73879311   70.38357075   55.96023483 1014.53483672
        8.92154779  160.86836216   11.02340278   75.09404061   27.07878658]
    


```python
data = np.array(res["x"])
```


```python
stations = df_s["Station"].unique()
WIND_BEARING_INDEXES = {}
WIND_SPEED_INDEXES = {}

WEATHER_VALUES = {"WIND_BEARING", "WIND_SPEED", "PRESSURE", "HUMIDITY", "TEMPERATURE"}
WEATHER_INDEXES = []

for i, item in df_s.loc[df_s["Pollution"] == "WIND_BEARING"].iterrows():
    WIND_BEARING_INDEXES[item["Station"]] = i

for i, item in df_s.loc[df_s["Pollution"] == "WIND_SPEED"].iterrows():
    WIND_SPEED_INDEXES[item["Station"]] = i

for i, item in df_s.iterrows():
    if item["Pollution"] in WEATHER_VALUES:
        WEATHER_INDEXES.append(i)

print(WIND_BEARING_INDEXES)
print(WIND_SPEED_INDEXES)
print(WEATHER_INDEXES)
```

    {' Miętowa, prusy': 6, ' Niepołomice szkolna': 14, ' Rynek mogilany': 22, ' Skała, rynek': 30, ' Wieliczka - Karola Kuczkiewicza': 38, ' liski, szkolna': 46, 'Aleja Zygmunta Krasińskiego': 53, 'Bulwarowa': 61, 'Emaus': 69, 'Franciszka Bujaka': 79, 'Kaszów, no2': 84, 'Krakowska - Zabierzów': 92, 'Skawina': 98, 'Węgrzce': 106, 'Świętego Wawrzyńca': 116}
    {' Miętowa, prusy': 7, ' Niepołomice szkolna': 15, ' Rynek mogilany': 23, ' Skała, rynek': 31, ' Wieliczka - Karola Kuczkiewicza': 39, ' liski, szkolna': 47, 'Aleja Zygmunta Krasińskiego': 54, 'Bulwarowa': 62, 'Emaus': 70, 'Franciszka Bujaka': 80, 'Kaszów, no2': 85, 'Krakowska - Zabierzów': 93, 'Skawina': 99, 'Węgrzce': 107, 'Świętego Wawrzyńca': 117}
    [0, 4, 5, 6, 7, 8, 12, 13, 14, 15, 16, 20, 21, 22, 23, 24, 28, 29, 30, 31, 32, 36, 37, 38, 39, 40, 44, 45, 46, 47, 53, 54, 61, 62, 68, 69, 70, 71, 77, 78, 79, 80, 84, 85, 91, 92, 93, 98, 99, 100, 104, 105, 106, 107, 108, 114, 115, 116, 117]
    


```python
def wind_to_cartesian(data):
    data = np.copy(data)
    for station in WIND_BEARING_INDEXES.keys():
        r = data[:, WIND_SPEED_INDEXES[station]]
        angle = data[:, WIND_BEARING_INDEXES[station]]
        x = r * np.cos(angle*np.pi/180)
        y = r * np.sin(angle*np.pi/180)
        data[:, WIND_SPEED_INDEXES[station]] = x
        data[:, WIND_BEARING_INDEXES[station]] = y
    return data


def wind_to_original(data):
    data = np.copy(data)
    for station in WIND_BEARING_INDEXES.keys():
        x = data[:, WIND_SPEED_INDEXES[station]]
        y = data[:, WIND_BEARING_INDEXES[station]]
        r = np.sqrt(x**2 + y**2)
        angle = (np.arctan2(y, x)/np.pi+1)*180
        data[:, WIND_SPEED_INDEXES[station]] = r
        data[:, WIND_BEARING_INDEXES[station]] = angle
    return data
```


```python
data = wind_to_cartesian(data)
```


```python
from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()
data = scaler.fit_transform(data)
```


```python
data = np.expand_dims(data, axis=1)
```


```python
print(data.shape)
print(data[:10, :, 0])
print(data[:10, :, 2])
print(data[:10, :, 4])
```

    (1960, 1, 118)
    [[0.08355697]
     [0.17814776]
     [0.36006652]
     [0.5095175 ]
     [0.63165514]
     [0.76330496]
     [0.87089877]
     [0.97382203]
     [1.06951496]
     [1.14331034]]
    [[2.09623064]
     [2.1783226 ]
     [2.60850025]
     [2.92622869]
     [3.14341023]
     [3.49768148]
     [4.11804231]
     [4.71615529]
     [4.9113777 ]
     [5.08568204]]
    [[-0.1020985 ]
     [-0.10146473]
     [-0.09682783]
     [-0.09150064]
     [-0.08981849]
     [-0.09323287]
     [-0.08480302]
     [-0.07288788]
     [-0.07857559]
     [-0.09521994]]
    


```python
from torch import nn
C = N

class ForecastModule(nn.Module):
    def __init__(self, element_size=106):
        super().__init__()
        self.lstm = nn.LSTM(element_size, C)
        self.h0 = torch.zeros(1, element_size)
        self.c0 = torch.zeros(1, C)
        
        
    def forward(self, inputs):
        if len(inputs) == 1:
            return self.lstm(inputs[0], (self.h0, self.c0))
        else:
            return self.lstm(inputs[0], (inputs[1], inputs[2]))
```


```python
import torch
import numpy as np


def train_one_epoch(model, optimizer, trainset):
    running_loss = 0.
    last_loss = 0.

    
    hiddens = torch.zeros(1, N)
    cells = torch.zeros(1, C)
    
    for i in range(trainset.shape[0]-1):
        # Every data instance is an input + label pair
        inputs, labels = torch.tensor(trainset[i], dtype=torch.float32), torch.tensor(trainset[i+1], dtype=torch.float32)

        # Zero your gradients for every batch!
        optimizer.zero_grad()
        if (i) % 24 == 0:
            hiddens = torch.zeros(1, N)
            cells = torch.zeros(1, C)
        outputs, (hidden, cell) = model([inputs, hiddens, cells])
        hiddens = hidden.detach()
        cells = cell.detach()
        
        # Compute the loss and its gradients
        loss = loss_fn(outputs, labels)
        
        loss.backward()

        # Adjust learning weights
        optimizer.step()

        # Gather data and report
        running_loss += loss.item()
        last_loss = running_loss / (i+1)
        print('batch {} loss: {}'.format(i + 1, last_loss/(i+1)), end='\r')
    print("")

    return last_loss
```


```python
EPOCHS = 60

trainset = data[24:-24]
valset = data[:24]
testset = data[-48:]

testset_airly_pred = predictions_data[-48:]
print(trainset.shape, valset.shape, testset.shape)
```

    (1912, 1, 118) (24, 1, 118) (48, 1, 118)
    


```python
model = ForecastModule(N)
loss_fn = torch.nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=1e-4, weight_decay=3e-5)

for i in model.parameters():
    print(i.shape)


epoch_number = 0

best_vloss = 1_000_000.
best_epoch = 0

for epoch in range(EPOCHS):
    print('EPOCH {}:'.format(epoch + 1))

    # Make sure gradient tracking is on, and do a pass over the data
    model.train(True)
    avg_loss = train_one_epoch(model, optimizer, trainset)

    # We don't need gradients on to do reporting
    model.train(False)

    running_vloss = 0.0

    with torch.no_grad():
        hidden_val = torch.zeros(1, N)
        cell_val = torch.zeros(1, C)
        for i in range(valset.shape[0]-1):
            vinputs, vlabels = torch.tensor(valset[i], dtype=torch.float32), torch.tensor(valset[i+1], dtype=torch.float32)
            voutputs, (hidden_val, cell_val) = model([vinputs, hidden_val, cell_val])
            vloss = loss_fn(voutputs, vlabels)
            running_vloss += vloss

    avg_vloss = running_vloss / (i + 1)
        
    print('Train loss: {}, Val loss: {}'.format(avg_loss, avg_vloss))

    # Track best performance, and save the model's state
    if avg_vloss < best_vloss:
        best_vloss = avg_vloss
        best_epoch = epoch
        model_path = 'model.pt'
        torch.save(model.state_dict(), model_path)
```

    torch.Size([472, 118])
    torch.Size([472, 118])
    torch.Size([472])
    torch.Size([472])
    EPOCH 1:
    batch 1911 loss: 0.00034114734594001863
    Train loss: 0.6519325780913756, Val loss: 2.404724597930908
    EPOCH 2:
    batch 1911 loss: 0.00022801656781816892
    Train loss: 0.4357396611005208, Val loss: 2.1621601581573486
    EPOCH 3:
    batch 1911 loss: 0.00018038032889255097
    Train loss: 0.3447068085136649, Val loss: 1.9237892627716064
    EPOCH 4:
    batch 1911 loss: 0.00015612104296146214
    Train loss: 0.29834731309935414, Val loss: 1.769681692123413
    EPOCH 5:
    batch 1911 loss: 0.00014161883469554834
    Train loss: 0.2706335931031929, Val loss: 1.6719834804534912
    EPOCH 6:
    batch 1911 loss: 0.00013210374988607032
    Train loss: 0.2524502660322804, Val loss: 1.6018333435058594
    EPOCH 7:
    batch 1911 loss: 0.00012554955546616823
    Train loss: 0.23992520049584748, Val loss: 1.5505807399749756
    EPOCH 8:
    batch 1911 loss: 0.00012090101694532084
    Train loss: 0.23104184338250813, Val loss: 1.5173060894012451
    EPOCH 9:
    batch 1911 loss: 0.00011752186362992645
    Train loss: 0.22458428139678943, Val loss: 1.4909931421279907
    EPOCH 10:
    batch 1911 loss: 0.00011500042166540464
    Train loss: 0.21976580580258825, Val loss: 1.4708921909332275
    EPOCH 11:
    batch 1911 loss: 0.00011306392591643952
    Train loss: 0.21606516242631593, Val loss: 1.4573770761489868
    EPOCH 12:
    batch 1911 loss: 0.00011153782639325645
    Train loss: 0.21314878623751307, Val loss: 1.4458208084106445
    EPOCH 13:
    batch 1911 loss: 0.00011030753702472664
    Train loss: 0.2107977032542525, Val loss: 1.4362797737121582
    EPOCH 14:
    batch 1911 loss: 0.00010932433669455924
    Train loss: 0.2089188074233027, Val loss: 1.4299067258834839
    EPOCH 15:
    batch 1911 loss: 0.00010851483755080138
    Train loss: 0.20737185455958126, Val loss: 1.4240505695343018
    EPOCH 16:
    batch 1911 loss: 0.00010783921423363377
    Train loss: 0.20608073840047414, Val loss: 1.4189751148223877
    EPOCH 17:
    batch 1911 loss: 0.00010727380587895531
    Train loss: 0.2050002430346836, Val loss: 1.4162945747375488
    EPOCH 18:
    batch 1911 loss: 0.00010678941863975268
    Train loss: 0.20407457902056736, Val loss: 1.410964846611023
    EPOCH 19:
    batch 1911 loss: 0.00010638576794798072
    Train loss: 0.2033032025485911, Val loss: 1.4082145690917969
    EPOCH 20:
    batch 1911 loss: 0.00010600994073722169
    Train loss: 0.20258499674883065, Val loss: 1.4045329093933105
    EPOCH 21:
    batch 1911 loss: 0.00010567368662399585
    Train loss: 0.20194241513845607, Val loss: 1.4022213220596313
    EPOCH 22:
    batch 1911 loss: 0.00010540974495388083
    Train loss: 0.20143802260686627, Val loss: 1.399324655532837
    EPOCH 23:
    batch 1911 loss: 0.00010514760724106242
    Train loss: 0.20093707743767028, Val loss: 1.3979750871658325
    EPOCH 24:
    batch 1911 loss: 0.00010493454463688615
    Train loss: 0.20052991480108942, Val loss: 1.3939099311828613
    EPOCH 25:
    batch 1911 loss: 0.00010471893251592802
    Train loss: 0.20011788003793846, Val loss: 1.392879605293274
    EPOCH 26:
    batch 1911 loss: 0.00010454765788942448
    Train loss: 0.1997905742266902, Val loss: 1.3902180194854736
    EPOCH 27:
    batch 1911 loss: 0.00010437260679314676
    Train loss: 0.19945605158170346, Val loss: 1.3899282217025757
    EPOCH 28:
    batch 1911 loss: 0.00010423072327597216
    Train loss: 0.1991849121803828, Val loss: 1.387681245803833
    EPOCH 29:
    batch 1911 loss: 0.00010408756873738108
    Train loss: 0.19891134385713524, Val loss: 1.3864965438842773
    EPOCH 30:
    batch 1911 loss: 0.00010396153390097358
    Train loss: 0.1986704912847605, Val loss: 1.385465145111084
    EPOCH 31:
    batch 1911 loss: 0.00010383066427578248
    Train loss: 0.19842039943102033, Val loss: 1.3854635953903198
    EPOCH 32:
    batch 1911 loss: 0.00010374320053710099
    Train loss: 0.1982532562264, Val loss: 1.3833752870559692
    EPOCH 33:
    batch 1911 loss: 0.00010362399564286565
    Train loss: 0.19802545567351618, Val loss: 1.384127140045166
    EPOCH 34:
    batch 1911 loss: 0.00010353785136498549
    Train loss: 0.19786083395848728, Val loss: 1.3821429014205933
    EPOCH 35:
    batch 1911 loss: 0.00010346340324207963
    Train loss: 0.19771856359561418, Val loss: 1.3820714950561523
    EPOCH 36:
    batch 1911 loss: 0.00010337799607274413
    Train loss: 0.19755535049501402, Val loss: 1.3805028200149536
    EPOCH 37:
    batch 1911 loss: 0.00010330476503791694
    Train loss: 0.19741540598745927, Val loss: 1.3793671131134033
    EPOCH 38:
    batch 1911 loss: 0.00010324338290821622
    Train loss: 0.19729810473760118, Val loss: 1.381296992301941
    EPOCH 39:
    batch 1911 loss: 0.00010318610679888775
    Train loss: 0.1971886500926744, Val loss: 1.378610610961914
    EPOCH 40:
    batch 1911 loss: 0.00010310465634104787
    Train loss: 0.19703299826774248, Val loss: 1.3791344165802002
    EPOCH 41:
    batch 1911 loss: 0.00010305793455528922
    Train loss: 0.1969437129351577, Val loss: 1.3772693872451782
    EPOCH 42:
    batch 1911 loss: 0.00010300822634195003
    Train loss: 0.1968487205394665, Val loss: 1.3771846294403076
    EPOCH 43:
    batch 1911 loss: 0.00010296824832837743
    Train loss: 0.19677232255552926, Val loss: 1.3764197826385498
    EPOCH 44:
    batch 1911 loss: 0.00010291390192015603
    Train loss: 0.19666846656941817, Val loss: 1.3762513399124146
    EPOCH 45:
    batch 1911 loss: 0.00010285738767340077
    Train loss: 0.19656046784386888, Val loss: 1.3751531839370728
    EPOCH 46:
    batch 1911 loss: 0.00010280328416341695
    Train loss: 0.19645707603628795, Val loss: 1.374884009361267
    EPOCH 47:
    batch 1911 loss: 0.00010278173710415922
    Train loss: 0.19641589960604827, Val loss: 1.3752230405807495
    EPOCH 48:
    batch 1911 loss: 0.00010276216986454408
    Train loss: 0.19637850661114373, Val loss: 1.372840166091919
    EPOCH 49:
    batch 1911 loss: 0.00010270279212451475
    Train loss: 0.1962650357499477, Val loss: 1.374597191810608
    EPOCH 50:
    batch 1911 loss: 0.00010267480793166993
    Train loss: 0.19621155795742123, Val loss: 1.3720922470092773
    EPOCH 51:
    batch 1911 loss: 0.00010263147626759023
    Train loss: 0.19612875114736492, Val loss: 1.3734543323516846
    EPOCH 52:
    batch 1911 loss: 0.00010261240021435201
    Train loss: 0.1960922968096267, Val loss: 1.3720468282699585
    EPOCH 53:
    batch 1911 loss: 0.00010257503480238691
    Train loss: 0.19602089150736138, Val loss: 1.372604489326477
    EPOCH 54:
    batch 1911 loss: 0.00010253991544924813
    Train loss: 0.1959537784235132, Val loss: 1.3711796998977661
    EPOCH 55:
    batch 1911 loss: 0.00010252091009185908
    Train loss: 0.1959174591855427, Val loss: 1.3713963031768799
    EPOCH 56:
    batch 1911 loss: 0.00010247875892865088
    Train loss: 0.19583690831265185, Val loss: 1.3716598749160767
    EPOCH 57:
    batch 1911 loss: 0.00010247419251384667
    Train loss: 0.19582818189396098, Val loss: 1.3704440593719482
    EPOCH 58:
    batch 1911 loss: 0.00010243503970422576
    Train loss: 0.19575336087477543, Val loss: 1.3711589574813843
    EPOCH 59:
    batch 1911 loss: 0.00010241171811014576
    Train loss: 0.19570879330848842, Val loss: 1.3707412481307983
    EPOCH 60:
    batch 1911 loss: 0.00010239212979826391
    Train loss: 0.19567136004448232, Val loss: 1.3690874576568604
    


```python
def predict(model, testset):
    print(testset.shape)
    print(testset.shape[0]//2)
    pre_set = testset[:testset.shape[0]//2]
    post_set = testset[testset.shape[0]//2:]
    print(post_set.shape)
    model.train(False)
    hidden = torch.zeros(1, N)
    cell = torch.zeros(1, N)
    outputs = []
    for i in range(pre_set.shape[0]):
        inputs = [torch.tensor(pre_set[i], dtype=torch.float32), hidden, cell]
        _, (hidden, cell) = model(inputs)
    input_data = torch.tensor(post_set[0], dtype=torch.float32)
    for i in range(post_set.shape[0]):
        input_data[0, WEATHER_INDEXES] = torch.tensor(post_set[i, 0, WEATHER_INDEXES], dtype=torch.float)
        inputs = [input_data, hidden, cell]
        output, (hidden, cell) = model(inputs)
        input_data = output.detach()
        outputs.append(output.detach().numpy())
    print(outputs[-1] - testset[-1, 0, :])
    return outputs, post_set
```


```python
outputs, post_set = predict(model, testset)
```

    (48, 1, 118)
    24
    (24, 1, 118)
    [[-8.97391584e-02 -1.84424593e-02  2.15809108e-01  1.68074087e-01
      -2.99566675e-03 -1.05026573e-01 -8.40699925e-02 -2.39719054e-01
       5.41386825e-02 -4.03602890e-01 -1.48425174e-02 -1.06568792e-01
      -4.66223920e-04 -1.11150354e-01  1.93881494e-03 -1.80887434e-01
      -2.47633533e-01 -9.66077246e-01 -8.02558478e-01 -7.14028612e-01
       1.27534090e-01 -1.21376816e-01  5.91201229e-02 -1.41857013e-01
      -2.49022401e-01  1.44134333e-01  2.00388955e-01  1.90071872e-01
       7.10376906e-02 -1.15472982e-01 -2.53144524e-01 -1.76136450e-01
      -2.75361708e-01 -3.20620113e-01 -1.22141511e-01 -1.19290605e-01
      -2.16968381e-02 -1.54620218e-01 -3.99814296e-02 -1.54633048e-01
      -2.57461152e-01 -3.65668132e-01 -2.23440158e-01 -1.78265370e-01
       9.35361706e-02 -1.57217606e-01 -4.75460295e-02 -1.76226299e-01
       1.00095458e+00  1.63580775e-02  1.20951219e+00  4.12459034e-01
       6.52052269e-02  4.88400078e-02 -5.24642180e-03  1.14601836e+00
       1.63581371e-02  5.97578091e-01  2.18897154e-01  1.55959424e-01
      -1.28550314e-01  5.01598631e-02  1.76248838e-03  9.24930237e-01
      -1.61259434e-01 -1.60355283e-01  1.30455699e-01  4.45567628e-02
      -8.86297720e-02 -1.53264713e-01 -2.59724973e-01 -3.73756413e-01
       6.29541613e-01  3.99971332e-01 -4.73454737e-01 -2.94215102e-01
      -2.88530781e-01  6.26571484e-02 -8.87401556e-02 -2.32405055e-02
      -2.02734343e-01  1.63577199e-02  5.31914671e-01  2.18639141e-01
       4.51142598e-02  1.39815300e-02  1.20878370e+00 -8.30242225e-01
      -2.00372390e-01 -1.45636942e-01 -9.19839191e-02  5.59053354e-02
      -1.30346285e-01 -1.83429400e-01  1.63583755e-02  8.87921165e-02
      -2.65383381e-03 -1.65891608e-01  4.91718385e-02  2.64910846e-02
      -2.19986866e-01 -3.79982585e-01 -3.47570676e-01 -2.41176211e-01
       6.27590661e-02 -1.14082903e-01 -9.65065839e-02 -2.19907931e-01
      -2.25033590e-01  1.15491707e+00 -2.22016023e-01 -4.21772398e-02
       2.29681730e-01  1.79835581e-01 -2.87902971e-03 -7.91947312e-02
      -5.08438570e-02 -2.05408746e-01]]
    


```python
print(outputs)
```

    [array([[ 8.2395345e-01,  6.0186595e-01,  6.6502243e-01,  5.9880310e-01,
            -3.7290031e-01,  1.4370711e+00,  8.1930041e-01,  4.5763978e-01,
             2.5698477e-01,  4.8027819e-01,  4.5364267e-01,  5.7385087e-01,
            -4.0469593e-01,  1.3922384e+00,  7.6169628e-01,  5.2693158e-01,
             8.4772503e-01,  4.4163933e-01,  6.5315491e-01,  5.4657602e-01,
            -3.7782454e-01,  1.5032248e+00,  7.8145581e-01,  5.5221367e-01,
             9.2782623e-01,  2.3659470e-02,  1.2614599e-01, -1.5502702e-02,
            -3.1311804e-01,  1.5274944e+00,  8.6232024e-01,  3.4211197e-01,
             1.0136180e+00,  4.3781540e-01,  5.2157855e-01,  4.8279905e-01,
            -4.1221443e-01,  1.4783298e+00,  7.9126263e-01,  5.4831284e-01,
             8.3948016e-01,  3.5716149e-01,  4.2147353e-01,  3.9141345e-01,
            -4.0282360e-01,  1.5027366e+00,  8.1860423e-01,  5.3505671e-01,
             5.0057966e-01, -9.8272485e-01, -4.9138698e-01,  8.8258833e-01,
             8.3839411e-01, -5.1910672e-02, -3.9556620e-01, -3.0870289e-01,
            -9.8272467e-01, -8.4476990e-01,  3.6279303e-01,  6.0027617e-01,
            -4.3253729e-01, -5.1910672e-02, -3.9556620e-01, -8.2416809e-01,
             8.0460012e-01,  7.7088678e-01,  8.0472988e-01,  7.6923400e-01,
            -3.8919720e-01,  8.9487320e-01,  6.6710985e-01,  9.8569524e-01,
            -9.0255594e-01, -2.1199371e-01,  9.8148584e-01,  9.8671228e-01,
             9.8168969e-01, -3.9868787e-01,  1.3277209e+00,  8.1877089e-01,
             5.9234971e-01, -9.8272556e-01, -5.4034770e-01, -9.8004323e-01,
            -5.1910672e-02, -3.9556620e-01, -9.3894976e-01,  1.0878809e-01,
             2.8011274e-01,  5.4848564e-01,  3.7550098e-01, -4.3156525e-01,
             8.4964281e-01,  4.1891739e-01, -9.8272467e-01, -5.9322357e-01,
             9.7011596e-02, -1.0482660e-03, -5.1910672e-02, -3.9556620e-01,
             9.4231403e-01,  5.7822704e-01,  5.3885531e-01,  5.3753901e-01,
            -4.2123577e-01,  1.3807367e+00,  8.1940001e-01,  4.9108699e-01,
             9.0568835e-01, -8.7871021e-01,  5.9189159e-02,  9.2339599e-01,
             9.5819712e-01,  9.4055027e-01, -4.8560166e-01,  1.4322553e+00,
             8.2288074e-01,  5.4375732e-01]], dtype=float32), array([[ 0.56177896,  0.55075216,  0.5994466 ,  0.53380495, -0.41071865,
             1.6740572 ,  0.89403397,  0.46254155,  0.09908891,  0.40348282,
             0.37187043,  0.49574104, -0.44554213,  1.5842208 ,  0.8392958 ,
             0.5495509 ,  0.69183797,  0.32695615,  0.53764   ,  0.43054867,
            -0.41568556,  1.6773466 ,  0.87557894,  0.60010165,  0.67384875,
             0.06606801,  0.15683027,  0.05509331, -0.34756994,  1.7384658 ,
             0.9380315 ,  0.35339296,  0.8130032 ,  0.39326516,  0.4249748 ,
             0.41126183, -0.45590904,  1.6996763 ,  0.88097125,  0.55583715,
             0.58359164,  0.22155263,  0.25041795,  0.2716082 , -0.4432226 ,
             1.6722547 ,  0.89583844,  0.5612783 ,  0.64755887, -0.98452836,
            -0.22506924,  0.86030626,  0.7611598 , -0.05191067, -0.3955662 ,
            -0.3456328 , -0.9845281 , -0.82736844,  0.36817098,  0.5413006 ,
            -0.49644423, -0.05191067, -0.3955662 , -0.8577618 ,  0.8278436 ,
             0.66380274,  0.7067403 ,  0.66547513, -0.44220307,  0.96657115,
             0.6707613 ,  0.7302304 , -0.8688072 , -0.07363852,  0.9609567 ,
             0.97004086,  0.9607444 , -0.44675878,  1.5422399 ,  0.90471095,
             0.5950055 , -0.9845288 , -0.53319633, -0.95091707, -0.05191067,
            -0.3955662 , -0.905184  ,  0.20142376,  0.22166532,  0.46229887,
             0.30563575, -0.47539604,  0.92670673,  0.42312583, -0.9845281 ,
            -0.63023895,  0.07617415, -0.05280481, -0.05191067, -0.3955662 ,
             0.6791642 ,  0.5019084 ,  0.45101577,  0.47341973, -0.46458733,
             1.5886929 ,  0.8993753 ,  0.49896038,  0.6963155 , -0.80339557,
             0.03981964,  0.85703135,  0.917996  ,  0.886779  , -0.5388971 ,
             1.6647055 ,  0.89436   ,  0.56861216]], dtype=float32), array([[ 0.3354932 ,  0.5371077 ,  0.55621034,  0.49425906, -0.45391932,
             1.8295404 ,  0.9599338 ,  0.41314948, -0.01598237,  0.35138026,
             0.30675194,  0.43767366, -0.47888404,  1.7282823 ,  0.898449  ,
             0.43647805,  0.5631889 ,  0.23085558,  0.42556182,  0.32297146,
            -0.4405753 ,  1.8260823 ,  0.93610597,  0.5501078 ,  0.4557515 ,
             0.12290128,  0.20958929,  0.12691648, -0.38128343,  1.9302193 ,
             0.9967093 ,  0.31287432,  0.5883613 ,  0.360231  ,  0.3516676 ,
             0.35765356, -0.48646381,  1.8554885 ,  0.9478991 ,  0.45341757,
             0.3488883 ,  0.11911973,  0.13636123,  0.18741488, -0.47452596,
             1.8227884 ,  0.9581865 ,  0.54332864,  0.7524111 , -0.98695594,
             0.06280969,  0.83262223,  0.7055952 , -0.05191067, -0.3955662 ,
            -0.34238538, -0.98695576, -0.8022091 ,  0.399981  ,  0.50429624,
            -0.5283604 , -0.05191067, -0.3955662 , -0.8714463 ,  0.864101  ,
             0.58264476,  0.61959386,  0.57889086, -0.48757565,  1.015774  ,
             0.6380582 ,  0.5151361 , -0.8268688 ,  0.03868158,  0.93828166,
             0.94774306,  0.9359975 , -0.4868198 ,  1.7308714 ,  0.97279763,
             0.54553455, -0.9869561 , -0.4987794 , -0.90790457, -0.05191067,
            -0.3955662 , -0.85194016,  0.26574326,  0.19833153,  0.40578267,
             0.2703251 , -0.5162279 ,  0.97514325,  0.40577528, -0.9869557 ,
            -0.65149534,  0.06922265, -0.09985051, -0.05191067, -0.3955662 ,
             0.43806216,  0.46349505,  0.38570112,  0.43562552, -0.5028733 ,
             1.7595587 ,  0.9638672 ,  0.4580152 ,  0.50840324, -0.7195536 ,
             0.03384558,  0.7937485 ,  0.86917883,  0.8255254 , -0.5782324 ,
             1.8299176 ,  0.97079706,  0.50695586]], dtype=float32), array([[ 0.22543663,  0.5467224 ,  0.53127825,  0.48190394, -0.49569997,
             1.8978629 ,  1.0017143 ,  0.36941817, -0.0949249 ,  0.33896905,
             0.26795024,  0.4170828 , -0.5173406 ,  1.8324387 ,  0.9452007 ,
             0.34737077,  0.48287752,  0.1537943 ,  0.32843217,  0.23280795,
            -0.4701697 ,  1.9212314 ,  0.96910954,  0.48480314,  0.3451787 ,
             0.20654643,  0.28161868,  0.2101182 , -0.41896808,  1.9915518 ,
             1.0324244 ,  0.28515887,  0.4417911 ,  0.33482745,  0.3053006 ,
             0.3205271 , -0.51722205,  1.9379191 ,  0.99153787,  0.36484903,
             0.20440803,  0.05579618,  0.08145293,  0.14396839, -0.50873756,
             1.9089361 ,  0.9877437 ,  0.48654372,  0.8194108 , -0.9881148 ,
             0.31589758,  0.79185313,  0.6650677 , -0.05191067, -0.3955662 ,
            -0.28823322, -0.9881145 , -0.7673196 ,  0.4362569 ,  0.48319718,
            -0.5392844 , -0.05191067, -0.3955662 , -0.8663089 ,  0.88889855,
             0.5288099 ,  0.5546715 ,  0.5128269 , -0.53549653,  1.0448467 ,
             0.575548  ,  0.39567566, -0.77290916,  0.11282087,  0.9162833 ,
             0.922062  ,  0.91063994, -0.52691656,  1.8335618 ,  0.9986894 ,
             0.46468866, -0.98811483, -0.45064116, -0.86357707, -0.05191067,
            -0.3955662 , -0.78065324,  0.28495905,  0.18642874,  0.38062704,
             0.26199207, -0.55840796,  0.99806637,  0.37016737, -0.98811454,
            -0.6633353 ,  0.05394351, -0.15571786, -0.05191067, -0.3955662 ,
             0.2877005 ,  0.44880572,  0.34256282,  0.41467994, -0.5445512 ,
             1.8588103 ,  1.0044057 ,  0.38355455,  0.38880804, -0.6098059 ,
             0.0248354 ,  0.7409954 ,  0.8176832 ,  0.76724094, -0.6183268 ,
             1.9169489 ,  1.0000885 ,  0.42854455]], dtype=float32), array([[ 0.15989457,  0.57131827,  0.5156708 ,  0.49203882, -0.5484779 ,
             1.9239358 ,  1.0124811 ,  0.3491344 , -0.13976876,  0.34800997,
             0.26079914,  0.43157452, -0.57321095,  1.9094427 ,  0.97697777,
             0.31384608,  0.44711545,  0.11068238,  0.27248412,  0.18002674,
            -0.51142645,  1.9664433 ,  0.9726733 ,  0.43112433,  0.31109813,
             0.33640608,  0.3916886 ,  0.3259744 , -0.46406102,  1.986796  ,
             1.0395756 ,  0.27772424,  0.4021776 ,  0.313109  ,  0.30217627,
             0.29027298, -0.56860596,  1.9767005 ,  1.0067171 ,  0.31211805,
             0.15157726,  0.0354836 ,  0.08829395,  0.1313965 , -0.55234534,
             1.9346864 ,  0.9747097 ,  0.4158546 ,  0.8493641 , -0.9880189 ,
             0.4612327 ,  0.72537893,  0.6341263 , -0.05191067, -0.3955662 ,
            -0.2049389 , -0.9880186 , -0.7340341 ,  0.45313007,  0.46858644,
            -0.55620813, -0.05191067, -0.3955662 , -0.8442437 ,  0.89692444,
             0.50851625,  0.53404963,  0.48426616, -0.5890982 ,  1.0479444 ,
             0.5613547 ,  0.37293914, -0.70031196,  0.15129298,  0.89502805,
             0.89092404,  0.8867223 , -0.5760881 ,  1.8657547 ,  0.9876976 ,
             0.42304292, -0.9880188 , -0.40928164, -0.8366111 , -0.05191067,
            -0.3955662 , -0.70085806,  0.270399  ,  0.18607591,  0.39322934,
             0.27480802, -0.60820365,  0.98854035,  0.3078396 , -0.98801863,
            -0.6720595 ,  0.01941299, -0.21872321, -0.05191067, -0.3955662 ,
             0.22089787,  0.4475818 ,  0.31707093,  0.40045545, -0.59535074,
             1.8969836 ,  1.0076526 ,  0.33881965,  0.34528378, -0.43779573,
             0.01139742,  0.7099656 ,  0.7771555 ,  0.735142  , -0.66554385,
             1.9400134 ,  0.99110335,  0.39252323]], dtype=float32), array([[ 0.10634786,  0.596569  ,  0.5204996 ,  0.51132435, -0.57674664,
             1.9415083 ,  0.99075353,  0.39538917, -0.16510355,  0.37199008,
             0.28679457,  0.4566817 , -0.6047199 ,  1.9572616 ,  0.9790186 ,
             0.33929512,  0.43308786,  0.10248215,  0.26109645,  0.16708073,
            -0.5406231 ,  1.9932542 ,  0.9638507 ,  0.49404284,  0.30804688,
             0.45465803,  0.5118888 ,  0.4518358 , -0.4771278 ,  1.9634155 ,
             0.9976487 ,  0.31238213,  0.3834786 ,  0.3239298 ,  0.30853802,
             0.28192723, -0.5994308 ,  2.002919  ,  0.99365276,  0.3591263 ,
             0.11708215,  0.05960201,  0.13546877,  0.15325072, -0.58644515,
             1.9545113 ,  0.96473825,  0.46259567,  0.8638404 , -0.9878851 ,
             0.5499075 ,  0.66763127,  0.6125739 , -0.05191067, -0.3955662 ,
            -0.10591332, -0.98788476, -0.7026993 ,  0.45465228,  0.4711147 ,
            -0.5869211 , -0.05191067, -0.3955662 , -0.8080614 ,  0.89355713,
             0.51452714,  0.5391191 ,  0.4866846 , -0.6243982 ,  1.0228038 ,
             0.6223913 ,  0.35835013, -0.6249983 ,  0.18954378,  0.885712  ,
             0.8688054 ,  0.87480223, -0.6083561 ,  1.9028544 ,  0.9640971 ,
             0.50016063, -0.9878851 , -0.35473555, -0.8271662 , -0.05191067,
            -0.3955662 , -0.6043885 ,  0.23016226,  0.21806656,  0.4334147 ,
             0.30368674, -0.63835716,  0.961982  ,  0.37334538, -0.98788494,
            -0.6708863 , -0.00865134, -0.2856756 , -0.05191067, -0.3955662 ,
             0.18061176,  0.4618476 ,  0.30937096,  0.40474442, -0.6253374 ,
             1.9263127 ,  0.9850869 ,  0.39737314,  0.33130333, -0.23372026,
            -0.03664434,  0.7101389 ,  0.7576733 ,  0.72979355, -0.69256043,
             1.9573402 ,  0.97344106,  0.47665396]], dtype=float32), array([[ 0.10069469,  0.6265474 ,  0.54565316,  0.5357183 , -0.5808878 ,
             1.8941256 ,  0.9457768 ,  0.46272784, -0.17115824,  0.42269725,
             0.33124033,  0.4943008 , -0.6135943 ,  1.9591277 ,  0.9550387 ,
             0.39696047,  0.4228499 ,  0.13588127,  0.2881931 ,  0.19286032,
            -0.5495891 ,  2.0349915 ,  0.939771  ,  0.62644947,  0.31851655,
             0.54692835,  0.6092289 ,  0.5527251 , -0.47087944,  1.9019375 ,
             0.95775545,  0.40518293,  0.34310457,  0.36897057,  0.32860747,
             0.30441868, -0.6076831 ,  2.0152752 ,  0.97368646,  0.46586466,
             0.11851946,  0.12267902,  0.20558573,  0.2140295 , -0.5949671 ,
             1.9591836 ,  0.93248856,  0.5911143 ,  0.8725046 , -0.9882092 ,
             0.60549164,  0.64018416,  0.6062639 , -0.05191067, -0.3955662 ,
             0.02304984, -0.98820883, -0.671283  ,  0.47176227,  0.4913487 ,
            -0.60905325, -0.05191067, -0.3955662 , -0.7610197 ,  0.88494253,
             0.5394422 ,  0.5541864 ,  0.5064089 , -0.6320123 ,  0.97026414,
             0.6912581 ,  0.36718097, -0.5498783 ,  0.24267197,  0.89308745,
             0.8650211 ,  0.8773869 , -0.6219531 ,  1.9862901 ,  0.9108676 ,
             0.5710738 , -0.98820925, -0.2725135 , -0.8395269 , -0.05191067,
            -0.3955662 , -0.48513314,  0.16074502,  0.28275496,  0.49477756,
             0.351853  , -0.63870096,  0.93111384,  0.48246652, -0.988209  ,
            -0.65990525, -0.00865059, -0.34716627, -0.05191067, -0.3955662 ,
             0.17366295,  0.48652473,  0.31830618,  0.42303762, -0.62418336,
             1.9075795 ,  0.9405237 ,  0.4953116 ,  0.34730995, -0.05177442,
            -0.10471395,  0.74118155,  0.7608075 ,  0.74368995, -0.6991409 ,
             1.9477854 ,  0.9239715 ,  0.5555136 ]], dtype=float32), array([[ 0.1672874 ,  0.657606  ,  0.57856977,  0.5644335 , -0.5692024 ,
             1.8007925 ,  0.89149415,  0.47799107, -0.14280732,  0.4997586 ,
             0.3956878 ,  0.5498641 , -0.6050664 ,  1.8697683 ,  0.9137245 ,
             0.409017  ,  0.46388593,  0.21053559,  0.36107394,  0.26750392,
            -0.5396754 ,  1.9798682 ,  0.85169226,  0.5833122 ,  0.36365238,
             0.6199174 ,  0.685225  ,  0.6255964 , -0.45188707,  1.8111228 ,
             0.919303  ,  0.41319373,  0.42967075,  0.43947822,  0.37789416,
             0.35898408, -0.58833206,  1.9502451 ,  0.9249639 ,  0.5127771 ,
             0.20022115,  0.2087244 ,  0.29801652,  0.30055147, -0.5807298 ,
             1.8862828 ,  0.86952144,  0.5826111 ,  0.87673914, -0.9882249 ,
             0.63469136,  0.63313425,  0.6084837 , -0.05191067, -0.3955662 ,
             0.18932396, -0.9882247 , -0.6311065 ,  0.4977418 ,  0.526622  ,
            -0.62784004, -0.05191067, -0.3955662 , -0.6968532 ,  0.86905354,
             0.5859901 ,  0.5814478 ,  0.5447218 , -0.6117784 ,  0.91136235,
             0.7130782 ,  0.42575973, -0.4671889 ,  0.2893851 ,  0.9102861 ,
             0.8769043 ,  0.8918719 , -0.60925514,  1.9228072 ,  0.85114914,
             0.586121  , -0.988225  , -0.16660088, -0.8669441 , -0.05191067,
            -0.3955662 , -0.35236937,  0.04245248,  0.36482248,  0.56960803,
             0.4179322 , -0.61994106,  0.87733936,  0.48159853, -0.9882248 ,
            -0.6434491 ,  0.03299826, -0.3886679 , -0.05191067, -0.3955662 ,
             0.22866502,  0.51651067,  0.34219977,  0.44434774, -0.6051752 ,
             1.8219513 ,  0.88187003,  0.5139246 ,  0.39409512,  0.10860712,
            -0.17461656,  0.78596705,  0.77890885,  0.7720206 , -0.676355  ,
             1.8618759 ,  0.8540412 ,  0.559336  ]], dtype=float32), array([[ 0.28005716,  0.68723065,  0.6096449 ,  0.59352905, -0.57270753,
             1.6651826 ,  0.85855573,  0.5021264 , -0.09673993,  0.5851194 ,
             0.46683896,  0.6115387 , -0.6006077 ,  1.7439047 ,  0.86402965,
             0.4086248 ,  0.52358747,  0.3094913 ,  0.4490832 ,  0.3620917 ,
            -0.5379258 ,  1.8494117 ,  0.7761894 ,  0.55858487,  0.46464026,
             0.6592478 ,  0.72649616,  0.6621663 , -0.45200664,  1.6800084 ,
             0.8972062 ,  0.457903  ,  0.5363085 ,  0.5185013 ,  0.43808332,
             0.43199813, -0.5831119 ,  1.8177843 ,  0.86686873,  0.48938182,
             0.3027164 ,  0.29999146,  0.38654244,  0.38614088, -0.5744301 ,
             1.7588282 ,  0.8116882 ,  0.591517  ,  0.8752861 , -0.98772246,
             0.6418082 ,  0.641638  ,  0.61530775, -0.05191067, -0.3955662 ,
             0.3764836 , -0.9877222 , -0.5825934 ,  0.51517665,  0.5668719 ,
            -0.6395249 , -0.05191067, -0.3955662 , -0.60872304,  0.84425026,
             0.6354135 ,  0.6190522 ,  0.5888779 , -0.60704064,  0.8742977 ,
             0.74058783,  0.51148033, -0.38796413,  0.32134318,  0.92816657,
             0.8957483 ,  0.90989304, -0.60948867,  1.7817338 ,  0.80737877,
             0.5858898 , -0.9877224 , -0.05026363, -0.8953615 , -0.05191067,
            -0.3955662 , -0.22650637, -0.10762177,  0.4417825 ,  0.6372731 ,
             0.48043293, -0.61553365,  0.8332459 ,  0.5193843 , -0.9877222 ,
            -0.6317985 ,  0.09243851, -0.41679204, -0.05191067, -0.3955662 ,
             0.30800352,  0.54730743,  0.36953488,  0.46626806, -0.60592353,
             1.7026744 ,  0.84237355,  0.5263543 ,  0.46334386,  0.21658337,
            -0.2488703 ,  0.831131  ,  0.80799156,  0.8050645 , -0.66279024,
             1.7360266 ,  0.79834217,  0.5421248 ]], dtype=float32), array([[ 0.41611433,  0.7148758 ,  0.6403617 ,  0.6226823 , -0.554764  ,
             1.5234805 ,  0.8030266 ,  0.53828084, -0.04631287,  0.6539434 ,
             0.5262716 ,  0.66239005, -0.5849966 ,  1.6091485 ,  0.78509873,
             0.44656226,  0.59949905,  0.40961102,  0.52849585,  0.44935372,
            -0.52933437,  1.7160465 ,  0.6954837 ,  0.5362171 ,  0.57286453,
             0.67031705,  0.7372349 ,  0.6680702 , -0.44217187,  1.545517  ,
             0.8636511 ,  0.51586974,  0.6412987 ,  0.5865747 ,  0.49318913,
             0.50048554, -0.5659473 ,  1.6814771 ,  0.7934046 ,  0.46765512,
             0.42241925,  0.37715825,  0.4548455 ,  0.45012727, -0.56210417,
             1.6209477 ,  0.75504035,  0.5760214 ,  0.86385834, -0.98713   ,
             0.62940073,  0.66475856,  0.62476593, -0.05191067, -0.3955662 ,
             0.54900146, -0.9871296 , -0.5257418 ,  0.53561085,  0.6014779 ,
            -0.64170563, -0.05191067, -0.3955662 , -0.49253628,  0.81243557,
             0.6819152 ,  0.65951455,  0.6321028 , -0.5849559 ,  0.7888891 ,
             0.71251696,  0.59180284, -0.31507832,  0.34415781,  0.94278497,
             0.91456044,  0.92664766, -0.59337145,  1.6457343 ,  0.7748805 ,
             0.5808637 , -0.9871299 ,  0.07252443, -0.91695523, -0.05191067,
            -0.3955662 , -0.1234463 , -0.26756963,  0.50524557,  0.6892708 ,
             0.53010476, -0.6017062 ,  0.78863126,  0.5432318 , -0.9871296 ,
            -0.62490535,  0.15426145, -0.43686166, -0.05191067, -0.3955662 ,
             0.45257184,  0.57272947,  0.39286387,  0.48558554, -0.5883038 ,
             1.5554128 ,  0.7922913 ,  0.528331  ,  0.5489875 ,  0.27504742,
            -0.3174697 ,  0.8688173 ,  0.83751297,  0.8338916 , -0.62836695,
             1.5830009 ,  0.73417145,  0.53353393]], dtype=float32), array([[ 0.5338924 ,  0.7360289 ,  0.6687574 ,  0.64675057, -0.5287429 ,
             1.4064648 ,  0.688887  ,  0.5857861 ,  0.00343092,  0.7019534 ,
             0.5694441 ,  0.69852793, -0.56080467,  1.4876242 ,  0.6700842 ,
             0.5320257 ,  0.67236555,  0.49666065,  0.59434885,  0.5227289 ,
            -0.5061495 ,  1.5687002 ,  0.5841845 ,  0.60958177,  0.658398  ,
             0.6594442 ,  0.72518325,  0.6497934 , -0.418307  ,  1.4203026 ,
             0.7356537 ,  0.577535  ,  0.7396542 ,  0.63958573,  0.54261816,
             0.56013876, -0.5391748 ,  1.5439271 ,  0.68963146,  0.53571844,
             0.5727618 ,  0.43389934,  0.496698  ,  0.48980275, -0.5353787 ,
             1.4713333 ,  0.62932914,  0.6537204 ,  0.8434841 , -0.9863128 ,
             0.59773314,  0.6954119 ,  0.6354337 , -0.05191067, -0.3955662 ,
             0.6815804 , -0.9863123 , -0.46176127,  0.5564778 ,  0.62788135,
            -0.6403737 , -0.05191067, -0.3955662 , -0.34220102,  0.77476686,
             0.7200756 ,  0.69591767,  0.66895455, -0.5406583 ,  0.6716469 ,
             0.8064598 ,  0.68623173, -0.26125637,  0.355508  ,  0.9532176 ,
             0.9301546 ,  0.9395473 , -0.5644159 ,  1.4988625 ,  0.67608964,
             0.65410244, -0.98631275,  0.18713035, -0.9313115 , -0.05191067,
            -0.3955662 , -0.04981283, -0.40926427,  0.5473632 ,  0.7233936 ,
             0.560126  , -0.57260346,  0.6887464 ,  0.61228776, -0.98631245,
            -0.6185331 ,  0.21205577, -0.45058736, -0.05191067, -0.3955662 ,
             0.5671444 ,  0.58816016,  0.41196665,  0.498276  , -0.55949366,
             1.4342289 ,  0.6816519 ,  0.5923044 ,  0.62904537,  0.29844227,
            -0.3728578 ,  0.8950335 ,  0.86189204,  0.8556055 , -0.59404707,
             1.4387549 ,  0.64120793,  0.58099014]], dtype=float32), array([[ 6.5277559e-01,  7.4856275e-01,  6.8971825e-01,  6.6056526e-01,
            -5.1198006e-01,  1.2982408e+00,  5.7467216e-01,  6.5521520e-01,
             8.1748776e-02,  7.3295796e-01,  6.0041338e-01,  7.2328800e-01,
            -5.4314834e-01,  1.3644170e+00,  5.4460269e-01,  6.0340220e-01,
             7.5659192e-01,  5.6443965e-01,  6.4679372e-01,  5.7948434e-01,
            -4.9105668e-01,  1.4400219e+00,  4.9778059e-01,  6.4284497e-01,
             7.7161038e-01,  6.3235849e-01,  7.0025873e-01,  6.1613721e-01,
            -4.0720338e-01,  1.3044115e+00,  6.0593432e-01,  7.0936257e-01,
             8.3859956e-01,  6.8041259e-01,  5.8882642e-01,  6.0638356e-01,
            -5.2319634e-01,  1.4205925e+00,  5.7464898e-01,  5.9248132e-01,
             6.8675464e-01,  4.7404414e-01,  5.2298772e-01,  5.1054436e-01,
            -5.1996464e-01,  1.3533726e+00,  5.3082734e-01,  6.9298625e-01,
             8.1071162e-01, -9.8559660e-01,  5.5186504e-01,  7.3111725e-01,
             6.4976078e-01, -5.1910672e-02, -3.9556620e-01,  7.6813644e-01,
            -9.8559624e-01, -3.9433184e-01,  5.7959330e-01,  6.4510989e-01,
            -6.3717437e-01, -5.1910672e-02, -3.9556620e-01, -1.7979525e-01,
             7.4006134e-01,  7.5319946e-01,  7.2673458e-01,  6.9990790e-01,
            -5.0641757e-01,  5.5135179e-01,  8.3993441e-01,  7.8751880e-01,
            -2.1276550e-01,  3.5987207e-01,  9.6117234e-01,  9.4303524e-01,
             9.4952506e-01, -5.4192555e-01,  1.3605746e+00,  5.6722420e-01,
             7.0760578e-01, -9.8559666e-01,  2.8819928e-01, -9.3962860e-01,
            -5.1910672e-02, -3.9556620e-01, -2.9496176e-04, -5.1495582e-01,
             5.7396710e-01,  7.4196595e-01,  5.7314742e-01, -5.5578417e-01,
             5.6287420e-01,  6.8443090e-01, -9.8559624e-01, -6.0656500e-01,
             2.6729876e-01, -4.5495251e-01, -5.1910672e-02, -3.9556620e-01,
             6.7991495e-01,  5.9364736e-01,  4.2417833e-01,  5.0268257e-01,
            -5.4289746e-01,  1.3232667e+00,  5.7371259e-01,  6.4559370e-01,
             7.0502657e-01,  2.8748664e-01, -4.1747835e-01,  9.1118068e-01,
             8.7960047e-01,  8.6898142e-01, -5.7863307e-01,  1.3238577e+00,
             5.5366594e-01,  6.3537252e-01]], dtype=float32), array([[ 0.76826596,  0.7517271 ,  0.70070434,  0.66440225, -0.49172333,
             1.2037168 ,  0.4785499 ,  0.6947672 ,  0.16344398,  0.7490017 ,
             0.61794233,  0.73638517, -0.5240835 ,  1.2611824 ,  0.44740623,
             0.6146144 ,  0.86118233,  0.6113783 ,  0.68393666,  0.61925393,
            -0.47044113,  1.3265151 ,  0.41572285,  0.61892605,  0.90026295,
             0.59424615,  0.66147226,  0.56878245, -0.39368746,  1.2320812 ,
             0.49229515,  0.7273739 ,  0.97882605,  0.7061884 ,  0.6212094 ,
             0.6389443 , -0.504412  ,  1.2966822 ,  0.47242016,  0.5933962 ,
             0.7864072 ,  0.49412137,  0.53179324,  0.5133099 , -0.50144124,
             1.2461395 ,  0.44939902,  0.6397702 ,  0.764033  , -0.98475343,
             0.481824  ,  0.7624645 ,  0.65979207, -0.05191067, -0.3955662 ,
             0.8157427 , -0.9847531 , -0.33094454,  0.5946472 ,  0.6511988 ,
            -0.6333851 , -0.05191067, -0.3955662 , -0.00944884,  0.7101549 ,
             0.7736913 ,  0.7465823 ,  0.72072124, -0.47044206,  0.44564888,
             0.8285264 ,  0.95453835, -0.18654516,  0.35389352,  0.96617496,
             0.9521188 ,  0.9560728 , -0.5142002 ,  1.2392404 ,  0.46356127,
             0.7148351 , -0.9847535 ,  0.36135975, -0.94249654, -0.05191067,
            -0.3955662 ,  0.02718641, -0.5843319 ,  0.5794333 ,  0.7447266 ,
             0.56894004, -0.5315716 ,  0.46127063,  0.6607922 , -0.984753  ,
            -0.5934274 ,  0.3196023 , -0.44891092, -0.05191067, -0.3955662 ,
             0.8092939 ,  0.58776474,  0.42370674,  0.49855626, -0.5210373 ,
             1.2222123 ,  0.47070098,  0.6546017 ,  0.81313527,  0.26019263,
            -0.4442339 ,  0.9181027 ,  0.8880169 ,  0.8731016 , -0.5577491 ,
             1.2185398 ,  0.44599965,  0.6301508 ]], dtype=float32), array([[ 0.89925367,  0.74736637,  0.7050689 ,  0.66203356, -0.4880814 ,
             1.125018  ,  0.41126642,  0.6903933 ,  0.27348393,  0.75164086,
             0.6247612 ,  0.73858064, -0.51678896,  1.1853445 ,  0.38622752,
             0.6149268 ,  0.99939185,  0.6343829 ,  0.703642  ,  0.64006734,
            -0.46362373,  1.2220188 ,  0.37070805,  0.58276016,  1.048318  ,
             0.5430915 ,  0.6098699 ,  0.5108174 , -0.38923496,  1.1593817 ,
             0.4247426 ,  0.6895055 ,  1.1313635 ,  0.71648914,  0.63877314,
             0.65610814, -0.500941  ,  1.1937319 ,  0.40773588,  0.5775313 ,
             0.93389916,  0.493796  ,  0.5205428 ,  0.49871725, -0.49655944,
             1.1622044 ,  0.39873987,  0.6057001 ,  0.7029696 , -0.98355794,
             0.38890064,  0.7875613 ,  0.66360855, -0.05191067, -0.3955662 ,
             0.8364752 , -0.98355746, -0.28415573,  0.59079117,  0.64797425,
            -0.62834245, -0.05191067, -0.3955662 ,  0.1384512 ,  0.6839286 ,
             0.78169674,  0.75699717,  0.7302986 , -0.46185723,  0.37042573,
             0.8045584 ,  1.1371635 , -0.18445596,  0.34748167,  0.9683776 ,
             0.95796764,  0.95951396, -0.5016565 ,  1.1370814 ,  0.38889185,
             0.70006216, -0.983558  ,  0.40247422, -0.9417905 , -0.05191067,
            -0.3955662 ,  0.03360652, -0.6206818 ,  0.56353754,  0.73293924,
             0.5455936 , -0.52185833,  0.41274124,  0.6550346 , -0.98355746,
            -0.58665305,  0.35814703, -0.4361985 , -0.05191067, -0.3955662 ,
             0.979354  ,  0.5712132 ,  0.40847933,  0.48715466, -0.51615953,
             1.1367105 ,  0.4074755 ,  0.6458581 ,  0.99734634,  0.22058056,
            -0.45725313,  0.9179884 ,  0.88964677,  0.8696712 , -0.5517033 ,
             1.096286  ,  0.3812381 ,  0.5797476 ]], dtype=float32), array([[ 1.0277779 ,  0.7348187 ,  0.70165974,  0.6531305 , -0.49433714,
             1.0457305 ,  0.38389432,  0.66992396,  0.36656776,  0.7415126 ,
             0.6191724 ,  0.73006153, -0.5216154 ,  1.1132307 ,  0.35407972,
             0.6304199 ,  1.1231159 ,  0.63428193,  0.7072249 ,  0.6433966 ,
            -0.47190547,  1.1462685 ,  0.34352383,  0.5659363 ,  1.1700637 ,
             0.48253652,  0.5483565 ,  0.444275  , -0.39771137,  1.0981544 ,
             0.40746775,  0.66118777,  1.2589887 ,  0.71514946,  0.6462322 ,
             0.6599213 , -0.5068657 ,  1.1170298 ,  0.3745125 ,  0.5853698 ,
             1.0738469 ,  0.47662783,  0.49333996,  0.46923456, -0.5016339 ,
             1.092695  ,  0.3690533 ,  0.5903992 ,  0.6220376 , -0.9822918 ,
             0.2744265 ,  0.8010343 ,  0.6631871 , -0.05191067, -0.3955662 ,
             0.8388441 , -0.9822915 , -0.26717386,  0.5695563 ,  0.6357641 ,
            -0.62514865, -0.05191067, -0.3955662 ,  0.24380411,  0.65728134,
             0.7827127 ,  0.761574  ,  0.7336523 , -0.46657676,  0.3484028 ,
             0.79860157,  1.2919351 , -0.19604583,  0.34478384,  0.968209  ,
             0.961051  ,  0.96051055, -0.49974045,  1.0450307 ,  0.349995  ,
             0.69286627, -0.98229194,  0.4039529 , -0.9395405 , -0.05191067,
            -0.3955662 ,  0.02519768, -0.64076245,  0.5324208 ,  0.708003  ,
             0.50817406, -0.5231693 ,  0.3819529 ,  0.63053197, -0.98229134,
            -0.5918637 ,  0.37394273, -0.41870248, -0.05191067, -0.3955662 ,
             1.1267129 ,  0.5417477 ,  0.37714553,  0.46407995, -0.521904  ,
             1.0547276 ,  0.36725065,  0.63444334,  1.1317916 ,  0.16848053,
            -0.45522773,  0.91303   ,  0.8862502 ,  0.86122084, -0.5556112 ,
             1.0075533 ,  0.34373295,  0.55162907]], dtype=float32), array([[ 1.14073   ,  0.7165462 ,  0.6922761 ,  0.6387803 , -0.49533737,
             0.9752388 ,  0.3884612 ,  0.6601368 ,  0.4471082 ,  0.7210278 ,
             0.6056012 ,  0.71276236, -0.52513796,  1.0453144 ,  0.35610452,
             0.6321415 ,  1.2229012 ,  0.61531514,  0.6956468 ,  0.63273907,
            -0.478407  ,  1.0837646 ,  0.32620868,  0.55657065,  1.2819315 ,
             0.4217223 ,  0.483559  ,  0.37616384, -0.4007408 ,  1.0274323 ,
             0.42093533,  0.6150384 ,  1.3493104 ,  0.7057192 ,  0.64680576,
             0.6532836 , -0.51074463,  1.0464482 ,  0.36070293,  0.60920864,
             1.2082887 ,  0.4475821 ,  0.45365226,  0.4300075 , -0.5053375 ,
             1.0223707 ,  0.358284  ,  0.59843844,  0.53309643, -0.9812061 ,
             0.16154987,  0.8094027 ,  0.6586103 , -0.05191067, -0.3955662 ,
             0.8307657 , -0.98120594, -0.2685536 ,  0.5342855 ,  0.6137248 ,
            -0.6255819 , -0.05191067, -0.3955662 ,  0.307552  ,  0.6324176 ,
             0.77949625,  0.76040417,  0.7326265 , -0.46906605,  0.3525113 ,
             0.7991496 ,  1.4192166 , -0.21791494,  0.34294888,  0.9666254 ,
             0.9626621 ,  0.96010345, -0.4978896 ,  0.96861696,  0.33320734,
             0.70052844, -0.98120636,  0.37457544, -0.93549645, -0.05191067,
            -0.3955662 ,  0.006055  , -0.6499243 ,  0.49266323,  0.6726391 ,
             0.46277416, -0.5219155 ,  0.37624025,  0.610343  , -0.98120564,
            -0.5999185 ,  0.3692875 , -0.3975294 , -0.05191067, -0.3955662 ,
             1.2460797 ,  0.50509846,  0.3356334 ,  0.43074384, -0.52255195,
             0.97580254,  0.3568519 ,  0.628774  ,  1.234362  ,  0.10710224,
            -0.4423759 ,  0.9041511 ,  0.8798023 ,  0.849734  , -0.5567117 ,
             0.93736535,  0.3437521 ,  0.5694356 ]], dtype=float32), array([[ 1.2308943 ,  0.6935711 ,  0.67642605,  0.6202288 , -0.48982766,
             0.9024268 ,  0.3916663 ,  0.6927538 ,  0.51647735,  0.69087213,
             0.58440095,  0.6869692 , -0.5193238 ,  0.96616316,  0.36261082,
             0.68125814,  1.3226779 ,  0.57988876,  0.67055386,  0.6099171 ,
            -0.47172332,  1.006181  ,  0.320781  ,  0.5500339 ,  1.3881773 ,
             0.3652007 ,  0.4228529 ,  0.311187  , -0.39708883,  0.9579486 ,
             0.4225024 ,  0.62731785,  1.417404  ,  0.68936896,  0.64024943,
             0.6380951 , -0.5073435 ,  0.9777262 ,  0.3684825 ,  0.64681935,
             1.3356645 ,  0.4098775 ,  0.40405574,  0.38651022, -0.49849388,
             0.9437173 ,  0.36384705,  0.6221045 ,  0.4503245 , -0.9802088 ,
             0.05849991,  0.8159102 ,  0.6523811 , -0.05191067, -0.3955662 ,
             0.8170972 , -0.98020846, -0.2795653 ,  0.4850267 ,  0.5863576 ,
            -0.62882555, -0.05191067, -0.3955662 ,  0.34179148,  0.61024356,
             0.771661  ,  0.75357765,  0.7273717 , -0.46324104,  0.37430352,
             0.83526355,  1.5121121 , -0.2394658 ,  0.3372704 ,  0.96334183,
             0.9627821 ,  0.9581752 , -0.4888474 ,  0.8982713 ,  0.33264458,
             0.7187884 , -0.98020893,  0.32246843, -0.93014896, -0.05191067,
            -0.3955662 , -0.01158839, -0.6524801 ,  0.44875485,  0.6287146 ,
             0.41534162, -0.5143687 ,  0.38543504,  0.6276929 , -0.9802083 ,
            -0.60706204,  0.3447725 , -0.37417677, -0.05191067, -0.3955662 ,
             1.3601826 ,  0.46400002,  0.28893116,  0.39072785, -0.51726496,
             0.90400416,  0.36282292,  0.6521656 ,  1.3223275 ,  0.04594143,
            -0.42398098,  0.890484  ,  0.86982983,  0.8351925 , -0.5505082 ,
             0.85949826,  0.35351616,  0.6038312 ]], dtype=float32), array([[ 1.3071148 ,  0.6657232 ,  0.6542739 ,  0.59735554, -0.48224095,
             0.8420022 ,  0.41015533,  0.7072119 ,  0.5787015 ,  0.65506154,
             0.5602819 ,  0.657035  , -0.50934327,  0.89804107,  0.37918788,
             0.6875642 ,  1.3834261 ,  0.5318635 ,  0.63443786,  0.57901776,
            -0.4673024 ,  0.93512106,  0.34438473,  0.5911988 ,  1.4758376 ,
             0.3130214 ,  0.36579478,  0.25349465, -0.39261943,  0.8934528 ,
             0.4335894 ,  0.65963894,  1.4840505 ,  0.6689361 ,  0.62930644,
             0.61894804, -0.5012999 ,  0.90879714,  0.3887444 ,  0.6673954 ,
             1.4558518 ,  0.36641133,  0.34976128,  0.34104308, -0.49258992,
             0.883219  ,  0.38366044,  0.6531603 ,  0.38196406, -0.97938776,
            -0.02382804,  0.8218811 ,  0.645514  , -0.05191067, -0.3955662 ,
             0.7998261 , -0.97938746, -0.29355952,  0.42802384,  0.553201  ,
            -0.63749033, -0.05191067, -0.3955662 ,  0.35787132,  0.5890841 ,
             0.7596435 ,  0.7434516 ,  0.7194648 , -0.45707923,  0.39939237,
             0.8736902 ,  1.5799115 , -0.25120097,  0.32054105,  0.95825124,
             0.9615999 ,  0.9549182 , -0.47953337,  0.8299252 ,  0.3696993 ,
             0.75428855, -0.979388  ,  0.25483412, -0.9239456 , -0.05191067,
            -0.3955662 , -0.02575705, -0.652291  ,  0.40227723,  0.5767331 ,
             0.3690161 , -0.5066502 ,  0.40447366,  0.66945964, -0.97938716,
            -0.6137247 ,  0.29462087, -0.3532926 , -0.05191067, -0.3955662 ,
             1.4477932 ,  0.41938052,  0.23978789,  0.34568083, -0.50986177,
             0.8467076 ,  0.3881516 ,  0.68535584,  1.3954213 , -0.00778685,
            -0.4086794 ,  0.87273425,  0.85837483,  0.8197116 , -0.54335314,
             0.79724056,  0.38077676,  0.64543235]], dtype=float32), array([[ 1.3585445 ,  0.63553876,  0.62882775,  0.57163984, -0.461996  ,
             0.80469936,  0.45113543,  0.7268803 ,  0.62008214,  0.6118426 ,
             0.5328947 ,  0.6251205 , -0.4879368 ,  0.84782946,  0.41996205,
             0.67711246,  1.4344461 ,  0.47434285,  0.5925748 ,  0.54325485,
            -0.44944704,  0.8920231 ,  0.3981717 ,  0.6258117 ,  1.5302936 ,
             0.26659954,  0.31524664,  0.20494945, -0.37763143,  0.8443389 ,
             0.49207124,  0.7026193 ,  1.5394279 ,  0.64386886,  0.61381155,
             0.59813976, -0.482644  ,  0.84493154,  0.4273923 ,  0.6658248 ,
             1.5439761 ,  0.32049304,  0.2961613 ,  0.29514286, -0.47600675,
             0.84628326,  0.41639924,  0.67211515,  0.33023676, -0.97873765,
            -0.09659516,  0.8258506 ,  0.63702977, -0.05191067, -0.3955662 ,
             0.78004694, -0.97873753, -0.31164235,  0.36163327,  0.5171705 ,
            -0.6498074 , -0.05191067, -0.3955662 ,  0.3621717 ,  0.570847  ,
             0.7437031 ,  0.7280029 ,  0.7088592 , -0.4387313 ,  0.4650331 ,
             0.9035423 ,  1.6293943 , -0.25954023,  0.28730637,  0.95110005,
             0.9593248 ,  0.95034504, -0.459615  ,  0.79024607,  0.41111493,
             0.7732132 , -0.97873807,  0.17990036, -0.9161413 , -0.05191067,
            -0.3955662 , -0.03889205, -0.6509127 ,  0.35214728,  0.51638705,
             0.32199547, -0.48952195,  0.44549605,  0.71717054, -0.9787372 ,
            -0.6206815 ,  0.22450997, -0.3316214 , -0.05191067, -0.3955662 ,
             1.5066142 ,  0.3720481 ,  0.19190572,  0.29890612, -0.49028033,
             0.810764  ,  0.42701012,  0.71138793,  1.4663198 , -0.05377974,
            -0.3940892 ,  0.8490914 ,  0.8446382 ,  0.80256987, -0.52499366,
             0.75722903,  0.42038292,  0.66236776]], dtype=float32), array([[ 1.3591249 ,  0.6033794 ,  0.60151446,  0.5453295 , -0.43518668,
             0.8032081 ,  0.5413915 ,  0.77623105,  0.6227233 ,  0.5612156 ,
             0.502483  ,  0.590528  , -0.46083918,  0.84816164,  0.5067767 ,
             0.7035217 ,  1.4518483 ,  0.40757012,  0.5446229 ,  0.50301874,
            -0.42681524,  0.87758225,  0.48539016,  0.66733   ,  1.5337336 ,
             0.22545399,  0.27176192,  0.16296107, -0.3522605 ,  0.82891357,
             0.59129184,  0.78071743,  1.541819  ,  0.61389583,  0.5930081 ,
             0.57587504, -0.45878947,  0.8348223 ,  0.50537074,  0.69558936,
             1.5721313 ,  0.27268854,  0.24635816,  0.25061727, -0.45026556,
             0.8394349 ,  0.5049678 ,  0.71683675,  0.29772487, -0.97832656,
            -0.1546199 ,  0.8277915 ,  0.62366253, -0.05191067, -0.3955662 ,
             0.7599502 , -0.97832644, -0.33219147,  0.2904049 ,  0.47907427,
            -0.66491413, -0.05191067, -0.3955662 ,  0.35729012,  0.5525247 ,
             0.7237763 ,  0.7074876 ,  0.6949178 , -0.411967  ,  0.5590081 ,
             0.930624  ,  1.6637905 , -0.26920596,  0.23963934,  0.9418235 ,
             0.95597965,  0.9448416 , -0.43331435,  0.7782913 ,  0.48917773,
             0.7854501 , -0.97832704,  0.10019416, -0.90742064, -0.05191067,
            -0.3955662 , -0.05464947, -0.6514609 ,  0.29867804,  0.45137495,
             0.27438918, -0.46331552,  0.5465284 ,  0.7830288 , -0.97832614,
            -0.63054955,  0.14079778, -0.31310782, -0.05191067, -0.3955662 ,
             1.5178334 ,  0.320135  ,  0.14476393,  0.2515307 , -0.46313992,
             0.8104741 ,  0.5137201 ,  0.74774235,  1.4785154 , -0.09503829,
            -0.38063967,  0.8193873 ,  0.82794744,  0.7833849 , -0.49977043,
             0.7576279 ,  0.51332885,  0.7214916 ]], dtype=float32), array([[ 1.2990766 ,  0.5707858 ,  0.5726068 ,  0.51729745, -0.39912948,
             0.84824675,  0.6390862 ,  0.8625687 ,  0.59204906,  0.5006636 ,
             0.46795225,  0.55115974, -0.42517465,  0.88488984,  0.59749055,
             0.78686386,  1.4291922 ,  0.33539805,  0.48659983,  0.45479923,
            -0.39338297,  0.8892123 ,  0.5822703 ,  0.7256048 ,  1.4864498 ,
             0.18850064,  0.23475452,  0.1277344 , -0.31705663,  0.85594326,
             0.6943639 ,  0.87150365,  1.4920664 ,  0.5807701 ,  0.5675772 ,
             0.55034405, -0.4235731 ,  0.87594056,  0.6048783 ,  0.78294295,
             1.5154812 ,  0.22543027,  0.19798866,  0.20760866, -0.4151129 ,
             0.8684672 ,  0.61895037,  0.7978691 ,  0.2874849 , -0.9786477 ,
            -0.18899038,  0.83062613,  0.61227936, -0.05191067, -0.3955662 ,
             0.7415247 , -0.9786476 , -0.36211646,  0.22914255,  0.44089594,
            -0.680002  , -0.05191067, -0.3955662 ,  0.3464264 ,  0.5391777 ,
             0.6996752 ,  0.68128836,  0.67562854, -0.3752392 ,  0.6758644 ,
             1.0079757 ,  1.6602494 , -0.28430688,  0.18815058,  0.93137395,
             0.9515139 ,  0.9389594 , -0.3973789 ,  0.78754264,  0.57083595,
             0.8312164 , -0.9786482 ,  0.02086974, -0.89860207, -0.05191067,
            -0.3955662 , -0.07889791, -0.6528623 ,  0.2497083 ,  0.38637686,
             0.23073766, -0.42915708,  0.6540682 ,  0.869771  , -0.97864735,
            -0.63753676,  0.05890907, -0.3038048 , -0.05191067, -0.3955662 ,
             1.4641752 ,  0.26775908,  0.100136  ,  0.20458417, -0.4269381 ,
             0.8543173 ,  0.61609274,  0.82969403,  1.4303155 , -0.13919336,
            -0.360488  ,  0.78563374,  0.8081695 ,  0.76147413, -0.4651586 ,
             0.80034703,  0.6200324 ,  0.81323355]], dtype=float32), array([[ 1.2028416 ,  0.5377976 ,  0.5404405 ,  0.48682478, -0.3567685 ,
             0.9117074 ,  0.76356775,  1.0093725 ,  0.5540329 ,  0.43932614,
             0.43476632,  0.51216215, -0.38767087,  0.94275784,  0.6872523 ,
             0.92096436,  1.3451766 ,  0.26325464,  0.41869676,  0.39922094,
            -0.35618243,  0.94358635,  0.6970924 ,  0.8339911 ,  1.3836958 ,
             0.15589684,  0.20092812,  0.10057738, -0.27963728,  0.9170215 ,
             0.8081281 ,  0.96534324,  1.3986074 ,  0.5488094 ,  0.5405971 ,
             0.5230095 , -0.38718686,  0.94975364,  0.7315764 ,  0.9178566 ,
             1.4022186 ,  0.17949142,  0.15170808,  0.16762754, -0.37854654,
             0.9417333 ,  0.7423036 ,  0.9079735 ,  0.3066706 , -0.97979397,
            -0.19002044,  0.83738434,  0.6037692 , -0.05191067, -0.3955662 ,
             0.72657824, -0.9797939 , -0.3938764 ,  0.18527322,  0.39861414,
            -0.6916674 , -0.05191067, -0.3955662 ,  0.33176416,  0.5353377 ,
             0.67099625,  0.6494905 ,  0.65142435, -0.33553806,  0.80908346,
             1.1096263 ,  1.5502467 , -0.30691138,  0.13102908,  0.92237127,
             0.9469428 ,  0.9340271 , -0.36210293,  0.8647431 ,  0.7079782 ,
             0.98773634, -0.9797945 , -0.04403673, -0.8890169 , -0.05191067,
            -0.3955662 , -0.10954997, -0.6546957 ,  0.20974043,  0.32582963,
             0.19419508, -0.39626873,  0.79150116,  0.98432857, -0.9797936 ,
            -0.63761705, -0.01450436, -0.30410817, -0.05191067, -0.3955662 ,
             1.3592277 ,  0.21869792,  0.05809725,  0.160368  , -0.38899657,
             0.91862273,  0.7462247 ,  0.96645266,  1.3424829 , -0.18607837,
            -0.33416915,  0.75124335,  0.7857619 ,  0.7377281 , -0.42982534,
             0.8685266 ,  0.7431307 ,  0.9617457 ]], dtype=float32), array([[ 1.0670938 ,  0.5069611 ,  0.5057954 ,  0.45396227, -0.30936098,
             0.9929832 ,  0.9072571 ,  1.0887028 ,  0.4745275 ,  0.3841564 ,
             0.39787856,  0.47208583, -0.34308752,  1.0032353 ,  0.843796  ,
             1.0340892 ,  1.2314695 ,  0.18963473,  0.34213868,  0.33195832,
            -0.31166008,  1.033797  ,  0.8505935 ,  0.95887405,  1.2329187 ,
             0.11772441,  0.16013612,  0.07454547, -0.23338492,  0.9998869 ,
             0.9339725 ,  1.0267298 ,  1.2652099 ,  0.51419735,  0.50941414,
             0.491968  , -0.34415978,  1.0604655 ,  0.890773  ,  1.032677  ,
             1.2451996 ,  0.13484532,  0.10670664,  0.12977378, -0.33322015,
             1.0452207 ,  0.8967162 ,  1.0081402 ,  0.34993216, -0.98161644,
            -0.17487186,  0.8467979 ,  0.59477407, -0.05191067, -0.3955662 ,
             0.7144365 , -0.98161644, -0.43367383,  0.16717876,  0.35274878,
            -0.698471  , -0.05191067, -0.3955662 ,  0.31340122,  0.54630595,
             0.63615125,  0.6049907 ,  0.61768353, -0.2826818 ,  0.97631156,
             1.1876283 ,  1.3642625 , -0.35343316,  0.07667836,  0.91581434,
             0.9419143 ,  0.929745  , -0.32052174,  0.96481395,  0.89608425,
             1.0951691 , -0.9816169 , -0.09137198, -0.8764801 , -0.05191067,
            -0.3955662 , -0.15111552, -0.6528526 ,  0.1743453 ,  0.2663853 ,
             0.16226302, -0.35458088,  0.9541526 ,  1.061674  , -0.9816162 ,
            -0.6346537 , -0.07886261, -0.3062593 , -0.05191067, -0.3955662 ,
             1.2058169 ,  0.17415233,  0.01800231,  0.11970005, -0.34181014,
             1.0047154 ,  0.90171474,  1.0718665 ,  1.2081732 , -0.2343614 ,
            -0.29357865,  0.7190575 ,  0.75909877,  0.71023077, -0.38695893,
             0.9508481 ,  0.9249222 ,  1.0798688 ]], dtype=float32), array([[ 0.9773547 ,  0.4777926 ,  0.46832302,  0.41766238, -0.31235665,
             0.8879566 ,  0.8231871 ,  0.8489837 ,  0.5286662 ,  0.3383846 ,
             0.35658905,  0.4366118 , -0.34355375,  0.89208496,  0.84573483,
             0.8532018 ,  0.98383594,  0.11284541,  0.25612155,  0.25470394,
            -0.184126  ,  0.91242015,  0.9097136 ,  0.817017  ,  0.9838964 ,
             0.07816688,  0.11737433,  0.04474869, -0.16234723,  0.8844139 ,
             0.680828  ,  0.8505933 ,  0.98984826,  0.47966635,  0.47113097,
             0.45962235, -0.36585662,  0.9058453 ,  0.8507916 ,  0.878044  ,
             0.98773843,  0.09561104,  0.06408843,  0.09721414, -0.23968397,
             0.8880031 ,  0.84917015,  0.8319139 ,  0.40160665, -0.9836419 ,
            -0.1428251 ,  0.85683554,  0.5847298 , -0.00307066, -0.40081263,
             0.7067562 , -0.98364186, -0.48853746,  0.17735785,  0.31299493,
            -0.69793326, -0.00175081, -0.39380372,  0.28642341,  0.56779736,
             0.59758925,  0.5490821 ,  0.57293975, -0.37131158,  0.82304686,
             0.9279033 ,  0.990506  , -0.4253877 ,  0.03411445,  0.9128128 ,
             0.9364538 ,  0.92600864, -0.2578646 ,  0.8760738 ,  0.87284374,
             0.8924347 , -0.9836423 , -0.12159743, -0.85948044, -0.00679641,
            -0.38158467, -0.20574097, -0.64304835,  0.14567679,  0.20755473,
             0.13480724, -0.29867554,  0.8238063 ,  0.87824464, -0.9836416 ,
            -0.6296882 , -0.12796274, -0.31010342, -0.00273883, -0.36907512,
             0.98583   ,  0.1373605 , -0.023543  ,  0.08038374, -0.27905107,
             0.8906325 ,  0.80520815,  0.8519586 ,  0.9831395 , -0.29279447,
            -0.23856206,  0.68940896,  0.7269174 ,  0.6767916 , -0.38983795,
             0.8716534 ,  0.8740784 ,  0.87446004]], dtype=float32)]
    


```python
predictions = np.array(outputs)
preds = scaler.inverse_transform(predictions)
real = scaler.inverse_transform(post_set)
print(preds.shape, real.shape)
preds = wind_to_original(preds[:, 0, :])
real = wind_to_original(real[:, 0, :])

```

    (24, 1, 118) (24, 1, 118)
    


```python
last_time = max(df_m['Time']) - pd.Timedelta(1, unit='D')
print(last_time)
```

    2023-06-09 08:00:00
    


```python
df_s['Pollution'].value_counts()
```




    Pollution
    WIND_BEARING    15
    WIND_SPEED      15
    PM10            14
    PM25            13
    PM1             11
    PRESSURE        11
    HUMIDITY         9
    TEMPERATURE      9
    NO2              8
    O3               5
    NO               4
    CO               2
    SO2              2
    Name: count, dtype: int64




```python
POLLUTION_TO_UNIT = {
    "PM1": "µg/m^3",
    "PM25": "µg/m^3",
    "PM10": "µg/m^3",
    "TEMPERATURE": "degrees C",
    "HUMIDITY": "%",
    "PRESSURE": "hPa",
    "WIND_SPEED": "km/h",
    "WIND_BEARING": "degrees",
    "NO2": "µg/m^3",
    "O3": "µg/m^3",
    "SO2": "µg/m^3",
    "CO": "µg/m^3",
    "H2S": "µg/m^3",
    "NO": "µg/m^3",
}
```


```python
print(testset_airly_pred.shape)
```

    (48, 118)
    


```python
def calc_errors(hours):
    subplots = MAX_SUBPLOTS
    errors = pd.DataFrame(data=[], columns=["RMSE", "Pollution", "Station", "Hours"])
    errors_airly = pd.DataFrame(data=[], columns=["RMSE", "Pollution", "Station", "Hours"])
    fig, ax = None, None
    to_show = df_s[df_s['Pollution'].isin(WEATHER_VALUES)].count()["Station"]
    k = 0
    for n in range(N):
        if df_s.loc[n]['Pollution'] in WEATHER_VALUES:
            continue
        if k%4 == 0:
            fig, ax = plt.subplots(1, min(4, to_show-k))
            fig.set_size_inches(min(4, to_show-k)*5, 4)
        times = [str(last_time + pd.Timedelta(i, unit='H')) for i in range(23)]
        ax[k%4].plot(times, preds[:-1, n], label="Predictions")
        ax[k%4].plot(times, real[1:, n], label="Correct values")
        if "PM10" in df_s.loc[n]['Pollution'] or "PM25" in df_s.loc[n]['Pollution']:
            ax[k%4].plot(times, testset_airly_pred[25:, n], label="Airly predictions")
            for i, hour in enumerate(hours):
                error_airly = np.sqrt(np.mean((preds[:hour-1, n] - testset_airly_pred[25:24+hour, n])**2))
                errors_airly.loc[k*len(hours) + i] = [error_airly, df_s.loc[n]['Pollution'], df_s.loc[n]['Station'], hour]
        for i, hour in enumerate(hours):
            error = np.sqrt(np.mean((preds[:hour-1, n] - real[1:hour, n])**2))
            errors.loc[k*len(hours) + i] = [error, df_s.loc[n]['Pollution'], df_s.loc[n]['Station'], hour]
        ax[k%4].set_title(f"{df_s.loc[n]['Station']}, {df_s.loc[n]['Pollution']}")
        ax[k%4].set_ylabel(f"Value [{POLLUTION_TO_UNIT[df_s.loc[n]['Pollution']]}]")
        ax[k%4].set_xlabel("Time [h]")
        ax[k%4].tick_params(axis='x', rotation=10)
        ax[k%4].set_xticks([times[0], times[8], times[16], times[-1]])
        ax[k%4].legend()
        if k%4 == 3:
            plt.show()
            fig.clear()
        k += 1
    return errors, errors_airly
```


```python
HOURS = [4, 6, 12, 24]
errors_df, errors_airly = calc_errors(HOURS)
```


    
![png](output_46_0.png)
    



    
![png](output_46_1.png)
    



    
![png](output_46_2.png)
    



    
![png](output_46_3.png)
    



    
![png](output_46_4.png)
    



    
![png](output_46_5.png)
    



    
![png](output_46_6.png)
    



    
![png](output_46_7.png)
    



    
![png](output_46_8.png)
    



    
![png](output_46_9.png)
    



    
![png](output_46_10.png)
    



    
![png](output_46_11.png)
    



    
![png](output_46_12.png)
    



    
![png](output_46_13.png)
    



    
![png](output_46_14.png)
    



```python
def plot_weather():
    fig, ax = None, None
    k = 0
    to_show = df_s[~df_s['Pollution'].isin(WEATHER_VALUES)].count()["Station"]
    for n in range(N):
        if df_s.loc[n]['Pollution'] not in WEATHER_VALUES:
            continue
        if k%4 == 0:
            fig, ax = plt.subplots(1, min(4, to_show-k))
            fig.set_size_inches(min(4, to_show-k)*5, 4)
        times = [str(last_time + pd.Timedelta(i, unit='H')) for i in range(23)]
        ax[k%4].plot(times, real[1:, n], label="Correct values")
        ax[k%4].set_title(f"{df_s.loc[n]['Station']}, {df_s.loc[n]['Pollution']}")
        ax[k%4].set_ylabel(f"Value [{POLLUTION_TO_UNIT[df_s.loc[n]['Pollution']]}]")
        ax[k%4].set_xlabel("Time [h]")
        ax[k%4].tick_params(axis='x', rotation=10)
        ax[k%4].set_xticks([times[0], times[8], times[16], times[-1]])
        if k%4 == 3:
            plt.show()
            fig.clear()
        k += 1
```


```python
plot_weather()
```


    
![png](output_48_0.png)
    



    
![png](output_48_1.png)
    



    
![png](output_48_2.png)
    



    
![png](output_48_3.png)
    



    
![png](output_48_4.png)
    



    
![png](output_48_5.png)
    



    
![png](output_48_6.png)
    



    
![png](output_48_7.png)
    



    
![png](output_48_8.png)
    



    
![png](output_48_9.png)
    



    
![png](output_48_10.png)
    



    
![png](output_48_11.png)
    



    
![png](output_48_12.png)
    



    
![png](output_48_13.png)
    



    
![png](output_48_14.png)
    



```python
def left_to_right(x, norm):
    return x/norm*100.

def right_to_left(x, norm):
    return x*norm/100.
```


```python
from functools import partial

POLLUTION_TO_NORM = {
    "PM1": 5,
    "PM25": 15,
    "PM10": 45,
    "NO2": 25,
    "O3": 100,
    "SO2": 40,
    "CO": 4000,
    "H2S": 100,
    "NO": 30,
}

def plot_errors(errors, hours):
    averages = {}
    n_index = 0
    fig, ax = None, None
    for hour in hours:
        n = 0
        for pollution in errors['Pollution'].unique():
            if pollution in WEATHER_VALUES:
                continue
            if n_index%4 == 0:
                fig, ax = plt.subplots(1, 4)
                fig.set_size_inches(36, 4)

            stations = []
            values = []
            for index, row in errors.loc[(errors["Pollution"] == pollution) & (errors["Hours"] == hour), ["RMSE", "Station"]].iterrows():
                stations.append(row["Station"])
                values.append(row["RMSE"])
            stations.append("Average")
            values.append(np.mean(np.array(values)))
            averages[(pollution, hour)] = np.mean(np.array(values))
            ax[n_index%4].bar(stations, values, width=0.4)
            ax[n_index%4].set_title(f"RMSE for {pollution}, for {hour}h")
            ax[n_index%4].set_ylabel(f"Value [{POLLUTION_TO_UNIT[pollution]}]")
            ax[n_index%4].tick_params(axis='x', rotation=90)

            norm = POLLUTION_TO_NORM[pollution]
            first = partial(left_to_right, norm=norm)
            second = partial(right_to_left, norm=norm)
            secax = ax[n_index%4].secondary_yaxis('right', functions=(first, second))
            secax.set_ylabel("Percentage of norm [%]")
            if n_index%4 == 3:
                plt.show()
                fig.clear()
            n+=1
            n_index += 1
    return averages
```


```python
df_averages = plot_errors(errors_df, HOURS)
```


    
![png](output_51_0.png)
    



    
![png](output_51_1.png)
    



    
![png](output_51_2.png)
    



    
![png](output_51_3.png)
    



    
![png](output_51_4.png)
    



    
![png](output_51_5.png)
    



    
![png](output_51_6.png)
    



    
![png](output_51_7.png)
    



```python
airly_averages = plot_errors(errors_airly, HOURS)
```


    
![png](output_52_0.png)
    



    
![png](output_52_1.png)
    



```python
def plot_averages(custom_averages, airly_averages, hours, pollutions):
    fig, ax = None, None
    n = 0
    for pollution in pollutions:
        if n%4 == 0:
            fig, ax = plt.subplots(1, 4)
            fig.set_size_inches(36, 5)
        values = []
        labels = []
        for hour in hours:
            values.append(custom_averages[(pollution, hour)])
            labels.append(f"Custom, {pollution} for {hour}h")
        if "PM10" in pollution or "PM25" in pollution:
            for hour in hours:
                values.append(airly_averages[(pollution, hour)])
                labels.append(f"Airly, {pollution} for {hour}h")

        ax[n%4].bar(labels, values, width=0.4)
        ax[n%4].set_title(f"Average RMSE for {pollution} based on period of prediction.")
        ax[n%4].set_ylabel(f"Value [{POLLUTION_TO_UNIT[pollution]}]")
        ax[n%4].tick_params(axis='x', rotation=90)

        norm = POLLUTION_TO_NORM[pollution]
        first = partial(left_to_right, norm=norm)
        second = partial(right_to_left, norm=norm)
        secax = ax[n%4].secondary_yaxis('right', functions=(first, second))
        secax.set_ylabel("Percentage of norm [%]")

        if n%4 == 3:
            plt.show()
            fig.clear()
        n += 1
```


```python
plot_averages(df_averages, airly_averages, HOURS, ["NO", "NO2", "SO2", "PM10", "PM25", "PM1", "CO", "O3"])
```


    
![png](output_54_0.png)
    



    
![png](output_54_1.png)
    



```python

```
